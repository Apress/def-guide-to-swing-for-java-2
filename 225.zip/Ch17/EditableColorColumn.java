import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

public class EditableColorColumn {

  public static void main(String args[]) {

    Color choices[] = {Color.red, Color.orange, Color.yellow, Color.green,
      Color.blue, Color.magenta};
    ComboTableCellRenderer renderer = new ComboTableCellRenderer();
    JComboBox comboBox = new JComboBox(choices);
    comboBox.setRenderer(renderer);
    TableCellEditor editor = new DefaultCellEditor(comboBox);

    JFrame frame = new ExitableJFrame("Editable Color Table");
    TableModel model = new ColorTableModel();
    JTable table = new JTable(model);

    TableColumn column = table.getColumnModel().getColumn(3);
    column.setCellRenderer(renderer);
    column.setCellEditor(editor);

    JScrollPane scrollPane = new JScrollPane(table);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(400, 150);
    frame.setVisible(true);
  }
}
