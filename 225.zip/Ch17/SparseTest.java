import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

public class SparseTest {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Sparse Test");
    String headers[] = {"English", "Japanese"};
    TableModel model = new SparseTableModel(10, headers);
    JTable table = new JTable(model);

    model.setValueAt("one", 0, 0);
    model.setValueAt("ten", 9, 0);
    model.setValueAt("roku - \u516D", 5, 1);
    model.setValueAt("hachi - \u516B", 8, 1);

    JScrollPane scrollPane = new JScrollPane(table);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
