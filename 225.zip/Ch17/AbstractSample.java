import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

public class AbstractSample {
  public static void main(String args[]) {
    TableModel model = new AbstractTableModel() {
      Object rowData[][] = {
        {"one",   "ichi"},
        {"two",   "ni"},
        {"three", "san"},
        {"four",  "shi"},
        {"five",  "go"},
        {"six",   "roku"},
        {"seven", "shichi"},
        {"eight", "hachi"},
        {"nine",  "kyu"},
        {"ten",   "ju"}
      };
      Object columnNames[] = {"English", "Japanese"};
      public String getColumnName(int column) {
        return columnNames[column].toString();
      }
      public int getRowCount() { 
        return rowData.length; 
      }
      public int getColumnCount() {
        return columnNames.length;
      }
      public Object getValueAt(int row, int col) {
        return rowData[row][col];
      }
    };
    JFrame frame = new ExitableJFrame("Abstract Sample");
    JTable table = new JTable(model);
    JScrollPane scrollPane = new JScrollPane(table);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
