import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import java.io.*;

public class LoadSave {

  public static void main (String args[]) {
    final String filename = "text.out";
    JFrame frame = new ExitableJFrame("Loading/Saving Example");
    Container content = frame.getContentPane();

    final JTextField textField = new JTextField();
    content.add(textField, BorderLayout.NORTH);

    JPanel panel = new JPanel();

    // Setup actions
    Action loadAction = new AbstractAction() {
      {
        putValue(Action.NAME, "Load");
      }
      public void actionPerformed(ActionEvent e) {
        doLoadCommand(textField, filename);
      }
    };
    JButton loadButton = new JButton (loadAction);
    panel.add(loadButton);

    Action saveAction = new AbstractAction() {
      {
        putValue(Action.NAME, "Save");
      }
      public void actionPerformed(ActionEvent e) {
        doSaveCommand(textField, filename);
      }
    };
    JButton saveButton = new JButton (saveAction);
    panel.add(saveButton);

    Action clearAction = new AbstractAction() {
      {
        putValue(Action.NAME, "Clear");
      }
      public void actionPerformed(ActionEvent e) {
        textField.setText("");
      }
    };
    JButton clearButton = new JButton (clearAction);
    panel.add(clearButton);

    content.add(panel, BorderLayout.SOUTH);

    frame.setSize(250, 150);
    frame.setVisible(true);
  }

  public static void doSaveCommand(JTextComponent textComponent, String filename) {
    FileWriter writer = null;
    try {
      writer = new FileWriter(filename);
      textComponent.write(writer);
    } catch (IOException exception) {
      System.out.println("Save oops");
      exception.printStackTrace();
    } finally {
      if (writer != null) {
        try {
          writer.close();
        } catch (IOException ignoredException) {
        }
      }
    }
  }

  public static void doLoadCommand(JTextComponent textComponent, String filename) {
    FileReader reader = null;
    try {
      reader = new FileReader(filename);
      textComponent.read(reader, filename);
    } catch (IOException exception) {
      System.out.println("Load oops");
      exception.printStackTrace();
    } finally {
      if (reader != null) {
        try {
          reader.close();
        } catch (IOException ignoredException) {
        }
      }
    }
  }
}
