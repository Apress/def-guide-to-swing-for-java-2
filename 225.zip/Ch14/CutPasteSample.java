import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.text.*;

public class CutPasteSample {
  public static void main (String args[]) {
    JFrame frame = new ExitableJFrame("Cut/Paste Example");
    Container content = frame.getContentPane();

    JTextField textField = new JTextField();
    JTextArea textArea = new JTextArea();
    JScrollPane scrollPane = new JScrollPane(textArea);

    content.add(textField, BorderLayout.NORTH);
    content.add(scrollPane, BorderLayout.CENTER);

    Action actions[] = textField.getActions();

    Action cutAction   = TextUtilities.findAction(actions, DefaultEditorKit.cutAction);
    Action copyAction  = TextUtilities.findAction(actions, DefaultEditorKit.copyAction);
    Action pasteAction = TextUtilities.findAction(actions, DefaultEditorKit.pasteAction);

    JPanel panel = new JPanel();
    content.add(panel, BorderLayout.SOUTH);

    JButton cutButton = new JButton(cutAction);
    cutButton.setText("Cut");
    panel.add(cutButton);

    JButton copyButton = new JButton(copyAction);
    copyButton.setText("Copy");
    panel.add(copyButton);

    JButton pasteButton = new JButton(pasteAction);
    pasteButton.setText("Paste");
    panel.add(pasteButton);

    frame.setSize(250, 250);
    frame.setVisible(true);
  }
}
