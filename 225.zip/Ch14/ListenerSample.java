import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

public class ListenerSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Offset Example");
    Container content = frame.getContentPane();
    JTextArea textArea = new JTextArea();
    JScrollPane scrollPane = new JScrollPane(textArea);
    final Document document = textArea.getDocument();
    DocumentListener listener = new DocumentListener() {
      public void changedUpdate(DocumentEvent documentEvent) {
        printInfo(documentEvent);
      }
      public void insertUpdate(DocumentEvent documentEvent) {
        printInfo(documentEvent);
      }
      public void removeUpdate(DocumentEvent documentEvent) {
        printInfo(documentEvent);
      }
      public void printInfo(DocumentEvent documentEvent) {
        System.out.println("Offset: " + documentEvent.getOffset());
        System.out.println("Length: " + documentEvent.getLength());
        DocumentEvent.EventType type = documentEvent.getType();
        String typeString = null;
        if (type.equals(DocumentEvent.EventType.CHANGE)) {
          typeString = "Change";
        } else if (type.equals(DocumentEvent.EventType.INSERT)) {
          typeString = "Insert";
        } else if (type.equals(DocumentEvent.EventType.REMOVE)) {
          typeString = "Remove";
        }
        System.out.println("Type  : " + typeString);
        Document documentSource = documentEvent.getDocument();
        Element rootElement = documentSource.getDefaultRootElement();
        DocumentEvent.ElementChange change = documentEvent.getChange(rootElement);
        System.out.println("Change: " + change);
      }
    };
    document.addDocumentListener(listener);

    content.add(scrollPane, BorderLayout.CENTER);
    frame.setSize(250, 150);
    frame.setVisible(true);
  }
}
