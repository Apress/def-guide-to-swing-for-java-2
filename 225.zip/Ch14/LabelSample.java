import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LabelSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Label Focus Example");
    Container content = frame.getContentPane();
    JPanel panel = new JPanel(new BorderLayout());
    JLabel label = new JLabel("Name: ");
    label.setDisplayedMnemonic(KeyEvent.VK_N);
    JTextField textField = new JTextField();
    label.setLabelFor(textField);
    panel.add(label, BorderLayout.WEST);
    panel.add(textField, BorderLayout.CENTER);
    content.add(panel, BorderLayout.NORTH);
    content.add(new JButton("Somewhere Else"), BorderLayout.SOUTH);
    frame.setSize(250, 150);
    frame.setVisible(true);
  }
}
