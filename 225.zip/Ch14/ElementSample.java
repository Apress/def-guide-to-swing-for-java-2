import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.text.*;

public class ElementSample {
  public static void main (String args[]) {
    JFrame frame = new ExitableJFrame("Element Example");
    Container content = frame.getContentPane();

    final JTextArea textArea = new JTextArea();
    JScrollPane scrollPane = new JScrollPane(textArea);

    JButton button = new JButton("Show Elements");
    ActionListener actionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        Document document = textArea.getDocument();
        ElementIterator iterator = new ElementIterator(document);
        Element element = iterator.first();
        while (element != null) {
          System.out.println(element.getStartOffset());
          element = iterator.next();
        }
      }
    };
    button.addActionListener(actionListener);

    content.add(scrollPane, BorderLayout.CENTER);
    content.add(button, BorderLayout.SOUTH);

    frame.setSize(250, 250);
    frame.setVisible(true);
  }
}
