import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.io.*;

public class EditorPaneSample {
  public static void main(String args[]) throws IOException {
    JFrame frame = new ExitableJFrame("EditorPane Example");
    Container content = frame.getContentPane();

    JEditorPane editorPane = new JEditorPane("http://www.apress.com");
    editorPane.setEditable(false);

    HyperlinkListener hyperlinkListener = new ActivatedHyperlinkListener(frame, editorPane);  
    editorPane.addHyperlinkListener(hyperlinkListener);

    JScrollPane scrollPane = new JScrollPane(editorPane);
    content.add(scrollPane);

    frame.setSize(640, 480);
    frame.setVisible(true);
  }
}
