import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

public class RangeSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Range Example");
    Container content = frame.getContentPane();
    content.setLayout(new GridLayout(3, 2));

    content.add(new JLabel("Range: 0-255"));
    Document rangeOne = new IntegerRangeDocument(0, 255);
    JTextField textFieldOne = new JTextField();
    textFieldOne.setDocument(rangeOne);
    content.add(textFieldOne);

    content.add(new JLabel("Range: -100-100"));
    Document rangeTwo = new IntegerRangeDocument(-100, 100);
    JTextField textFieldTwo = new JTextField();
    textFieldTwo.setDocument(rangeTwo);
    content.add(textFieldTwo);

    content.add(new JLabel("Range: 1000-2000"));
    Document rangeThree = new IntegerRangeDocument(1000, 2000);
    JTextField textFieldThree = new JTextField();
    textFieldThree.setDocument(rangeThree);
    content.add(textFieldThree);

    frame.setSize(250, 150);
    frame.setVisible(true);
  }
}
