import javax.swing.*;
import javax.swing.text.*;
import java.util.Hashtable;
public class TextUtilities {
  private TextUtilities() {
  }

  public static Action findAction(Action actions[], String key) {
    Hashtable commands = new Hashtable();
    for (int i = 0; i < actions.length; i++) {
      Action action = actions[i];
      commands.put(action.getValue(Action.NAME), action);
    }
    return (Action)commands.get(key);
  }
}