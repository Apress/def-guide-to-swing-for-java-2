import javax.swing.*;
import java.awt.*;

public class TextAreaSample {
  public static void main(String args[]) {
    String title = (args.length==0 ? "TextArea Example" : args[0]);
    JFrame frame = new ExitableJFrame(title);
    Container content = frame.getContentPane();

    content.setLayout(new GridLayout(0, 2));

    JTextArea leftTextArea = new JTextArea();
    content.add(leftTextArea);
    leftTextArea.paste();

    JTextArea rightTextArea = new JTextArea() {
      public boolean isManagingFocus() {
        return false;
      }
    };
    rightTextArea.paste();

    JScrollPane rightPane = new JScrollPane(rightTextArea);
    content.add(rightPane);

    frame.setSize(250, 150);
    frame.setVisible(true);
  }
}
