import javax.swing.*;
import java.awt.*;

public class SeparatorSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Separator Example");
    JSeparator north = new JSeparator(JSeparator.HORIZONTAL);
    JSeparator south = new JSeparator(JSeparator.VERTICAL);
    JSeparator east = new JSeparator(JSeparator.HORIZONTAL);
    JSeparator west = new JSeparator(JSeparator.VERTICAL);
    Container contentPane = frame.getContentPane();
    contentPane.add(north, BorderLayout.NORTH);
    contentPane.add(south, BorderLayout.SOUTH);
    contentPane.add(east, BorderLayout.EAST);
    contentPane.add(west, BorderLayout.WEST);
    frame.setSize(350, 250);
    frame.setVisible(true);
  }
}
