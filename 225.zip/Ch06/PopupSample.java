import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class PopupSample {

  public static void main(String args[]) {
    // Define ActionListener
    ActionListener actionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        System.out.println("Selected: " + actionEvent.getActionCommand());
      }
    };

    // Define PopupMenuListener
    PopupMenuListener popupMenuListener = new PopupMenuListener() {
      public void popupMenuCanceled(PopupMenuEvent popupMenuEvent) {
        System.out.println("Canceled");
      }
      public void popupMenuWillBecomeInvisible(PopupMenuEvent popupMenuEvent) {
        System.out.println("Becoming Invisible");
      }
      public void popupMenuWillBecomeVisible(PopupMenuEvent popupMenuEvent) {
        System.out.println("Becoming Visible");
      }
    };

    // Create frame
    JFrame frame = new ExitableJFrame("Popup Example");

    // Create popup menu, attach popup menu listener
    JPopupMenu popupMenu = new JPopupMenu();
    popupMenu.addPopupMenuListener(popupMenuListener);

     // Cut
    JMenuItem cutMenuItem = new JMenuItem("Cut");
    cutMenuItem.addActionListener(actionListener);
    popupMenu.add(cutMenuItem);

    // Copy
    JMenuItem copyMenuItem = new JMenuItem("Copy");
    copyMenuItem.addActionListener(actionListener);
    popupMenu.add(copyMenuItem);

    // Paste
    JMenuItem pasteMenuItem = new JMenuItem("Paste");
    pasteMenuItem.addActionListener(actionListener);
    pasteMenuItem.setEnabled(false);
    popupMenu.add(pasteMenuItem);

    // Separator
    popupMenu.addSeparator();

    // Find
    JMenuItem findMenuItem = new JMenuItem("Find");
    findMenuItem.addActionListener(actionListener);
    popupMenu.add(findMenuItem);

    // Enable showing by binding popup to frame
    MouseListener mouseListener = new JPopupMenuShower(popupMenu);
    frame.addMouseListener (mouseListener);

    frame.setSize(350, 250);
    frame.setVisible(true);
  }
}
