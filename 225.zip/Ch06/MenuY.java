import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class MenuY {
  static class MenuActionListener implements ActionListener {
    public void actionPerformed (ActionEvent e) {
      System.out.println ("Selected: " + e.getActionCommand());
    }
  }
  static class MyMenuListener implements MenuListener {
    public void menuCanceled(MenuEvent e) {
      System.out.println("Canceled");
    }
    public void menuDeselected(MenuEvent e) {
      System.out.println("Deselected");
    }
    public void menuSelected(MenuEvent e) {
      System.out.println("Selected");
    }
  }
  static class MyChangeListener implements ChangeListener {
    public void stateChanged(ChangeEvent event) {
      Object source = event.getSource();
      if (source instanceof AbstractButton) {
        AbstractButton aButton = (AbstractButton)source;
        ButtonModel aModel = aButton.getModel();
        boolean armed = aModel.isArmed();
        boolean pressed = aModel.isPressed();
        boolean selected = aModel.isSelected();
        System.out.println("Changed " + aButton.getText() + ": " + armed + "/" + pressed + "/" + selected);
/*      } else if (source instanceof MenuSelectionManager) {
        MenuSelectionManager manager = (MenuSelectionManager)source;
        MenuElement path[] = manager.getSelectedPath();
        for (int i=0, n=path.length; i<n; i++) {
          MenuElement item = (MenuElement)path[i];
          System.out.print ("-->" + item.getClass().getName());
        }
        System.out.println();
*/      }
    }
  }

  static class MyMenuKeyListener implements MenuKeyListener {
    public void menuKeyPressed (MenuKeyEvent e) {
      printInfo("Pressed", e);
    }
    public void menuKeyReleased (MenuKeyEvent e) {
      printInfo("Released", e);
    }
    public void menuKeyTyped (MenuKeyEvent e) {
      printInfo("Typed", e);
    }
    private void printInfo (String eventType, MenuKeyEvent e) {
      System.out.print (eventType + ":");
      MenuElement path[] = e.getPath();
/*      for (int i=0, n=path.length; i<n; i++) {
        MenuElement item = (MenuElement)path[i];
        System.out.print ("==>" + item.getClass().getName());
      }
*/      System.out.println();
    }
  }

  public static void main(String args[]) {
    ActionListener actionListener = new MenuActionListener();
    MenuKeyListener menuKeyListener = new MyMenuKeyListener();
    ChangeListener cListener = new MyChangeListener();
    MenuListener menuListener = new MyMenuListener();
    MenuSelectionManager manager = MenuSelectionManager.defaultManager();
    manager.addChangeListener(cListener);
    JFrame frame = new ExitableJFrame("MenuSample Example");
    JMenuBar bar = new VerticalMenuBar();
//    JMenuBar bar = new JMenuBar();

    // File Menu, F - Mnemonic
    JMenu file = new JMenu("File");
    file.setMnemonic(KeyEvent.VK_F);
    file.addChangeListener(cListener);
    file.addMenuListener(menuListener);
    file.addMenuKeyListener(menuKeyListener);
    JPopupMenu popupMenu = file.getPopupMenu();
    popupMenu.setLayout(new GridLayout(3,3));
    bar.add(file);

    // File->New, N - Mnemonic
    JMenuItem newItem = new JMenuItem("New", KeyEvent.VK_N);
    newItem.addActionListener(actionListener);
    newItem.addChangeListener(cListener);
    newItem.addMenuKeyListener(menuKeyListener);
    file.add(newItem);

    // File->Open, O - Mnemonic
    JMenuItem openItem = new JMenuItem("Open", KeyEvent.VK_O);
    openItem.addActionListener(actionListener);
    openItem.addChangeListener(cListener);
    openItem.addMenuKeyListener(menuKeyListener);
    file.add(openItem);

    // File->Close, C - Mnemonic
    JMenuItem closeItem = new JMenuItem("Close", KeyEvent.VK_C);
    closeItem.addActionListener(actionListener);
    closeItem.addChangeListener(cListener);
    closeItem.addMenuKeyListener(menuKeyListener);
    file.add(closeItem);

    // Separator
    file.addSeparator();

    // File->Save, S - Mnemonic
    JMenuItem saveItem = new JMenuItem("Save", KeyEvent.VK_S);
    saveItem.addActionListener(actionListener);
    saveItem.addChangeListener(cListener);
    saveItem.addMenuKeyListener(menuKeyListener);
    file.add(saveItem);

    // Separator
    file.addSeparator();

    // File->Exit, X - Mnemonic
    JMenuItem exitItem = new JMenuItem("Exit", KeyEvent.VK_X);
    exitItem.addActionListener(actionListener);
    exitItem.addChangeListener(cListener);
    exitItem.addMenuKeyListener(menuKeyListener);
    file.add(exitItem);

    // Edit Menu, E - Mnemonic
    JMenu edit = new JMenu("Edit");
    edit.setMnemonic(KeyEvent.VK_E);
    edit.addChangeListener(cListener);
    edit.addMenuListener(menuListener);
    edit.addMenuKeyListener(menuKeyListener);
    bar.add(edit);

    // Edit->Cut, T - Mnemonic, CTRL-X - Accelerator
    JMenuItem cutItem = new JMenuItem("Cut", KeyEvent.VK_T);
    cutItem.addActionListener(actionListener);
    cutItem.addChangeListener(cListener);
    cutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, Event.CTRL_MASK));
    cutItem.addMenuKeyListener(menuKeyListener);
    edit.add(cutItem);

    // Edit->Copy, C - Mnemonic, CTRL-C - Accelerator
    JMenuItem copyItem = new JMenuItem("Copy", KeyEvent.VK_C);
    copyItem.addActionListener(actionListener);
    copyItem.addChangeListener(cListener);
    copyItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, Event.CTRL_MASK));
    copyItem.addMenuKeyListener(menuKeyListener);
    copyItem.setEnabled(false);
    edit.add(copyItem);

    // Edit->Paste, P - Mnemonic, CTRL-V - Accelerator, Disabled
    JMenuItem pasteItem = new JMenuItem("Paste", KeyEvent.VK_P);
    pasteItem.addActionListener(actionListener);
    pasteItem.addChangeListener(cListener);
    pasteItem.addMenuKeyListener(menuKeyListener);
    pasteItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, Event.CTRL_MASK));
    pasteItem.setEnabled(false);
    edit.add(pasteItem);

    // Separator
    edit.addSeparator();

    // Edit->Find, F - Mnemonic, F3 - Accelerator
    JMenuItem findItem = new JMenuItem("Find", KeyEvent.VK_F);
    findItem.addActionListener(actionListener);
    findItem.addChangeListener(cListener);
    findItem.addMenuKeyListener(menuKeyListener);
    findItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0));
    edit.add(findItem);

    // Edit->Options Submenu, O - Mnemonic, at.gif - Icon Image File
    Icon atIcon = new ImageIcon("at.gif");
    Action findAction = new AbstractAction("Options", atIcon) {
      ActionListener actionListener = new MenuActionListener();
      public void actionPerformed (ActionEvent e) {
        actionListener.actionPerformed(e);
      }
    };
    findAction.putValue(Action.MNEMONIC_KEY, new Integer(KeyEvent.VK_O));
    JMenuItem jMenuItem = new JMenuItem(findAction);

    JMenu findOptions = new JMenu(findAction);
    findOptions.addChangeListener(cListener);
    findOptions.addMenuListener(menuListener);
    findOptions.addMenuKeyListener(menuKeyListener);

    // ButtonGrou for radio buttons
    ButtonGroup directionGroup = new ButtonGroup();

    // Edit->Options->Forward, F - Mnemonic, in group
    JRadioButtonMenuItem forward = new JRadioButtonMenuItem("Forward", true);
    forward.addActionListener(actionListener);
    forward.addChangeListener(cListener);
    forward.addMenuKeyListener(menuKeyListener);
    forward.setMnemonic(KeyEvent.VK_F);
    findOptions.add(forward);
    directionGroup.add(forward);

    // Edit->Options->Backward, B - Mnemonic, in group
    JRadioButtonMenuItem backward = new JRadioButtonMenuItem("Backward");
    backward.addActionListener(actionListener);
    backward.addChangeListener(cListener);
    backward.addMenuKeyListener(menuKeyListener);
    backward.setMnemonic(KeyEvent.VK_B);
    findOptions.add(backward);
    directionGroup.add(backward);

    // Separator
    findOptions.addSeparator();

    // Edit->Options->Case Sensitive, C - Mnemonic
    JCheckBoxMenuItem caseItem = new JCheckBoxMenuItem("Case Sensitive");
    caseItem.addActionListener(actionListener);
    caseItem.addChangeListener(cListener);
    caseItem.addMenuKeyListener(menuKeyListener);
    caseItem.setMnemonic(KeyEvent.VK_C);
    findOptions.add(caseItem);
    edit.add(findOptions);

    frame.setJMenuBar(bar);
//    frame.getContentPane().add(bar, BorderLayout.EAST);
    frame.setSize(350, 250);
    frame.setVisible(true);
  }
}
