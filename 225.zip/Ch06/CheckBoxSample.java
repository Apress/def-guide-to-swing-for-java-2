import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CheckBoxSample {
  static Icon boyIcon = new ImageIcon("boy-r.jpg");
  static Icon girlIcon = new ImageIcon("girl-r.jpg");

  public static void main(String args[]) {

    ActionListener aListener = new ActionListener() {
      public void actionPerformed (ActionEvent event) {
        AbstractButton aButton = (AbstractButton)event.getSource();
        boolean selected = aButton.getModel().isSelected();
        String newLabel;
        Icon newIcon;
        if (selected) {
          newLabel = "Girl";
          newIcon = girlIcon;
        } else {
          newLabel = "Boy";
          newIcon = boyIcon;
        }
        aButton.setText(newLabel);
        aButton.setIcon(newIcon); 
      }
    };

    ItemListener iListener = new ItemListener() {
      public void itemStateChanged(ItemEvent event) {
        AbstractButton aButton = (AbstractButton)event.getSource();
        int state = event.getStateChange();
        String newLabel;
        Icon newIcon;
        if (state == ItemEvent.SELECTED) {
          newLabel = "Girl";
          newIcon = girlIcon;
        } else {
          newLabel = "Boy";
          newIcon = boyIcon;
        }
        aButton.setText(newLabel);
        aButton.setIcon(newIcon); 
      }
    };

    JFrame frame = new ExitableJFrame("CheckBox Example");
    JMenuBar bar = new JMenuBar();
    JMenu menu = new JMenu("Menu");
    menu.setMnemonic(KeyEvent.VK_M);
    JCheckBoxMenuItem one = new JCheckBoxMenuItem();
    menu.add(one);
    JCheckBoxMenuItem two = new JCheckBoxMenuItem("Boy");
    menu.add(two);
    JCheckBoxMenuItem three = new JCheckBoxMenuItem(boyIcon);
    menu.add(three);
    JCheckBoxMenuItem four = new JCheckBoxMenuItem("Girl", true);
    menu.add(four);
    JCheckBoxMenuItem five = new JCheckBoxMenuItem("Boy", boyIcon);
    five.addItemListener(iListener);
    menu.add(five);
    Icon stateIcon = new DiamondAbstractButtonStateIcon(Color.black);

    UIManager.put("CheckBoxMenuItem.checkIcon", stateIcon);
    JCheckBoxMenuItem six = new JCheckBoxMenuItem("Girl", girlIcon, true);
    six.addActionListener(aListener);
    menu.add(six);

    bar.add(menu);
    frame.setJMenuBar(bar);
    frame.setSize(350, 250);
    frame.setVisible(true);
  }
}
