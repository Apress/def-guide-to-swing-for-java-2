import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ToolBarSample extends JPanel {

  private static final int COLOR_POSITION = 0;
  private static final int STRING_POSITION = 1;
  static Object buttonColors[][] = {
    {Color.red, "red"}, 
    {Color.blue, "blue"},
    {Color.green, "green"},
    {Color.black, "black"},
    null, // separator
    {Color.cyan, "cyan"}
  };

  public static void main (String args[]) {

    ActionListener actionListener = new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        System.out.println(actionEvent.getActionCommand());
      }
    };

    JFrame frame = new ExitableJFrame("JToolBar Example");

    JToolBar toolbar = new JToolBar();
    toolbar.putClientProperty("JToolBar.isRollover", Boolean.TRUE);

    for (int i=0, n=buttonColors.length; i<n; i++) {
      Object color[] = buttonColors[i];
      if (color == null) {
        toolbar.addSeparator();
      } else {
        Icon icon = new DiamondIcon((Color)color[COLOR_POSITION], true, 20, 20);
        JButton button = new JButton(icon);
        button.setActionCommand((String)color[STRING_POSITION]);
        button.addActionListener(actionListener);
        toolbar.add(button);
      }
    }

    Action action = new ActionMenuSample.ShowAction(frame);
    toolbar.add(action);

    Container contentPane = frame.getContentPane();
    contentPane.add(toolbar, BorderLayout.NORTH);
    JTextArea textArea = new JTextArea();
    JScrollPane pane = new JScrollPane(textArea);
    contentPane.add(pane, BorderLayout.CENTER);
    frame.setSize(350, 150);
    frame.setVisible(true);
  }
}
