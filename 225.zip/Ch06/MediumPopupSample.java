import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class MediumPopupSample {

  public static void main(String args[]) {
    // Define ActionListener
    ActionListener aListener = new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        System.out.println("Selected: " + event.getActionCommand());
      }
    };

    // Define PopupMenuListener
    PopupMenuListener pListener = new PopupMenuListener() {
      public void popupMenuCanceled(PopupMenuEvent event) {
        System.out.println("Canceled");
      }
      public void popupMenuWillBecomeInvisible(PopupMenuEvent event) {
        System.out.println("Becoming Invisible");
      }
      public void popupMenuWillBecomeVisible(PopupMenuEvent event) {
        System.out.println("Becoming Visible");
      }
    };

    // Define 
    JFrame frame = new ExitableJFrame("Popup Example");

    JPopupMenu.setDefaultLightWeightPopupEnabled(false);

    // Create popup menu, attach popup menu listener
    final JPopupMenu popupMenu = new JPopupMenu();
    popupMenu.addPopupMenuListener(pListener);

     // Cut
    JMenuItem cutItem = new JMenuItem("Cut");
    cutItem.addActionListener(aListener);
    popupMenu.add(cutItem);

    // Copy
    JMenuItem copyItem = new JMenuItem("Copy");
    copyItem.addActionListener(aListener);
    popupMenu.add(copyItem);

    // Paste
    JMenuItem pasteItem = new JMenuItem("Paste");
    pasteItem.addActionListener(aListener);
    pasteItem.setEnabled(false);
    popupMenu.add(pasteItem);

    // Separator
    popupMenu.addSeparator();

    // Find
    JMenuItem findItem = new JMenuItem("Find");
    findItem.addActionListener(aListener);
    popupMenu.add(findItem);

    // Enable showing
    MouseListener mouseListener = new JPopupMenuShower(popupMenu);
    frame.addMouseListener (mouseListener);

    Button button = new Button ("Label");
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        System.out.println (popupMenu.isLightWeightPopupEnabled());
      }
    });
    frame.getContentPane().add(button, BorderLayout.SOUTH);


    frame.setSize(350, 250);
    frame.setVisible(true);
  }
}
