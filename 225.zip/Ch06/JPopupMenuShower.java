import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JPopupMenuShower extends MouseAdapter {

  private JPopupMenu popup;

  public JPopupMenuShower(JPopupMenu popup) {
    this.popup = popup;
  }

  private void showIfPopupTrigger(MouseEvent mouseEvent) {
    if (popup.isPopupTrigger(mouseEvent)) {
      popup.show(mouseEvent.getComponent(), mouseEvent.getX(), mouseEvent.getY());
    }
  }

  public void mousePressed(MouseEvent mouseEvent) {
    showIfPopupTrigger(mouseEvent);
  }
  public void mouseReleased(MouseEvent mouseEvent) {
    showIfPopupTrigger(mouseEvent);
  }
}

