import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class TestApplet extends JApplet {
  protected JRootPane createRootPane() {
    System.out.println("Creating...");
    JRootPane pane = new JRootPane();
    pane.putClientProperty("defeatSystemEventQueueCheck", Boolean.TRUE);
    return pane;
  }
  public void init() {
    JButton button = new JButton("Select");
    ActionListener actionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        System.out.println("Selected");
      }
    };
    button.addActionListener(actionListener);
    Container container = getContentPane();
    container.add(button, BorderLayout.SOUTH);
  }
}