import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class DesktopSample {

  public static void main(String[] args) {
    String title = (args.length==0 ? "Desktop Sample" : args[0]);
    JFrame frame = new ExitableJFrame(title);

    JDesktopPane desktop = new JDesktopPane();
    JInternalFrame internalFrames[] = {
      new JInternalFrame("Can Do All", true, true, true, true),
      new JInternalFrame("Not Resizable", false, true, true, true),
      new JInternalFrame("Not Closable", true, false, true, true),
      new JInternalFrame("Not Maximizable", true, true, false, true),
      new JInternalFrame("Not Iconifiable", true, true, true, false)
    };

    InternalFrameListener internalFrameListener = new InternalFrameIconifyListener();

    for(int i=0, n=internalFrames.length; i<n; i++) {
      // Add to desktop
      desktop.add(internalFrames[i]);

      // Position and size
      internalFrames[i].setBounds(i*25, i*25, 200, 100);

      // Add listener for iconification events
      internalFrames[i].addInternalFrameListener(internalFrameListener);

      JLabel label = new JLabel(internalFrames[i].getTitle(), JLabel.CENTER);
      Container content = internalFrames[i].getContentPane();
      content.add(label, BorderLayout.CENTER);

      // Make visible
      internalFrames[i].setVisible(true);
    }

    JInternalFrame palette = new JInternalFrame("Palette", true, false, true, false);
    palette.setBounds(350, 150, 100, 100);
    palette.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
    desktop.add(palette, JDesktopPane.PALETTE_LAYER);
    palette.setVisible(true);

    desktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);

    Container content = frame.getContentPane();
    content.add(desktop, BorderLayout.CENTER);
    frame.setSize(500, 300);
    frame.setVisible(true);
  }
}
