import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class NoButtonPopup {
  public static void main(String args[]) {

    JFrame frame = new ExitableJFrame("NoButton Popup");
    JButton button = new JButton ("Ask");
    ActionListener actionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        Component source = (Component)actionEvent.getSource();
        int response = JOptionPane.showOptionDialog(
          source,
          "",
          "Empty?", 
          JOptionPane.DEFAULT_OPTION,
          JOptionPane.QUESTION_MESSAGE,
          null,
          new Object[] {},
          null);
        System.out.println ("Response: " + response);
      }
    };
    button.addActionListener(actionListener);
    Container contentPane = frame.getContentPane();
    contentPane.add(button, BorderLayout.SOUTH);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
