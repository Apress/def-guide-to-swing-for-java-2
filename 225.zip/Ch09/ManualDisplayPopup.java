import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ManualDisplayPopup {
  public static void main(String args[]) {

    JFrame frame = new ExitableJFrame("NoButton Popup");
    JButton button = new JButton ("Ask");
    ActionListener actionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        Component source = (Component)actionEvent.getSource();
        JOptionPane optionPane = new JOptionPane("Continue printing?", JOptionPane.QUESTION_MESSAGE, JOptionPane.YES_NO_OPTION);
        JDialog dialog = optionPane.createDialog(source, "Manual Creation");
        dialog.show();
        int selection = OptionPaneUtils.getSelection(optionPane);
        System.out.println (selection);
      }
    };
    button.addActionListener(actionListener);
    Container contentPane = frame.getContentPane();
    contentPane.add(button, BorderLayout.SOUTH);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
