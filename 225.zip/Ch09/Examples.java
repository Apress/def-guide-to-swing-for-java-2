import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Examples {
  public static void main(String args[]) {

    JFrame frame = new ExitableJFrame("Example Popup");
    Container contentPane = frame.getContentPane();
    contentPane.setLayout(new GridLayout(0, 1));

    JFrame frame2 = new ExitableJFrame("Desktop");
    final JDesktopPane desktop = new JDesktopPane();
    frame2.getContentPane().add(desktop);
    JButton pick = new JButton("Pick");
    pick.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        System.out.println ("Hi");
      }
    });
    frame2.getContentPane().add(pick, BorderLayout.SOUTH);

    JButton messagePopup = new JButton ("Message");
    contentPane.add(messagePopup);
    messagePopup.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        Component source = (Component)actionEvent.getSource();
        JOptionPane.showMessageDialog(source, "Printing complete");
        JOptionPane.showInternalMessageDialog(desktop, "Printing complete");
      }
    });

    JButton confirmPopup = new JButton ("Confirm");
    contentPane.add(confirmPopup);
    confirmPopup.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        Component source = (Component)actionEvent.getSource();
        JOptionPane.showConfirmDialog(source, "Continue printing?");
        JOptionPane.showInternalConfirmDialog(desktop, "Continue printing?");
      }
    });

    JButton inputPopup = new JButton ("Input");
    contentPane.add(inputPopup);
    inputPopup.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        Component source = (Component)actionEvent.getSource();
        JOptionPane.showInputDialog(source, "Enter printer name:");
        // Moons of Neptune
        String smallList[] = {"Naiad", "Thalassa", "Despina", "Galatea", "Larissa", "Proteus", "Triton", "Nereid"};
        JOptionPane.showInternalInputDialog(desktop, "Pick a printer", "Input", JOptionPane.QUESTION_MESSAGE, null, smallList, "Triton");
        // Moons of Saturn - includes two provisional designations to make 20
        String bigList[] = {"Pan", "Atlas", "Prometheus", "Pandora", "Epimetheus", "Janus", "Mimas", "Enceladus", "Tethys", "Telesto", "Calypso", "Dione", "Helene", "Rhea", "Titan", "Hyperion", "Iapetus", "Phoebe", "S/1995 S 2", "S/1981 S 18"};
//        Object saturnMoon = JOptionPane.showInputDialog(source, "Pick a printer", "Input", JOptionPane.QUESTION_MESSAGE, null, bigList, "Titan");
        Object saturnMoon = JOptionPane.showInputDialog(source, "Pick a printer", "Input", JOptionPane.QUESTION_MESSAGE, null, bigList, null);
        System.out.println ("Saturn Moon: " + saturnMoon);
      }
    });

    JButton optionPopup = new JButton ("Option");
    contentPane.add(optionPopup);
    optionPopup.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        Component source = (Component)actionEvent.getSource();

        Icon greenIcon = new DiamondIcon(Color.green);
        Icon redIcon = new DiamondIcon(Color.red);
        Object iconArray[] = {greenIcon, redIcon};
        JOptionPane.showOptionDialog(source, "Continue printing?", "Select an Option", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, iconArray, iconArray[1]);

        Icon blueIcon = new DiamondIcon(Color.blue);
        Object stringArray[] = {"Do It", "No Way"};
        JOptionPane.showInternalOptionDialog(desktop, "Continue printing?", "Select an Option", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, blueIcon, stringArray, stringArray[0]);
      }
    });

    frame.setSize(300, 200);
    frame.setVisible(true);
    frame2.setSize(300, 200);
    frame2.setVisible(true);
  }
}
