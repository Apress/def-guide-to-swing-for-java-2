import java.awt.*;
import java.awt.event.*;

public class KeyTextComponent extends Canvas {
  private ActionListener actionListenerList = null;

  public KeyTextComponent() {
    setBackground(Color.cyan);
    KeyListener internalKeyListener = new KeyAdapter() {
      public void keyPressed(KeyEvent keyEvent) {
        if (actionListenerList != null) {
          int keyCode = keyEvent.getKeyCode();
          String keyText = KeyEvent.getKeyText(keyCode);
          ActionEvent actionEvent = new ActionEvent(
            this,
            ActionEvent.ACTION_PERFORMED,
            keyText);
          actionListenerList.actionPerformed(actionEvent);
        }
      }
    };

    MouseListener internalMouseListener = new MouseAdapter() {
      public void mousePressed(MouseEvent mouseEvent) {
        requestFocus();
      }
    };

    addKeyListener(internalKeyListener);
    addMouseListener(internalMouseListener);
  }

  public void addActionListener(ActionListener actionListener) {
    actionListenerList = AWTEventMulticaster.add(actionListenerList, actionListener);
  }
  public void removeActionListener(ActionListener actionListener) {
    actionListenerList = AWTEventMulticaster.remove(actionListenerList, actionListener);
  }

  public boolean isFocusTraversable() {
    return true;
  }
}