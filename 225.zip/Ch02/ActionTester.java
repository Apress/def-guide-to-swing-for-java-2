import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ActionTester {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Action Sample");
    final Action printAction = new PrintHelloAction();

    JMenuBar menuBar = new JMenuBar();
    JMenu menu = new JMenu("File");
    menuBar.add(menu);
    menu.add(printAction);

    JToolBar toolbar = new JToolBar();
    toolbar.add(printAction);

    JButton enableButton = new JButton("Enable");
    ActionListener enableActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        printAction.setEnabled(true);
      }
    };
    enableButton.addActionListener(enableActionListener);

    JButton disableButton = new JButton("Disable");
    ActionListener disableActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        printAction.setEnabled(false);
      }
    };
    disableButton.addActionListener(disableActionListener);

    JButton relabelButton = new JButton("Relabel");
    ActionListener relabelActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        printAction.putValue(Action.NAME, "Hello World");
      }
    };
    relabelButton.addActionListener(relabelActionListener);

    JPanel buttonPanel = new JPanel();
    buttonPanel.add(enableButton);
    buttonPanel.add(disableButton);
    buttonPanel.add(relabelButton);

    frame.setJMenuBar(menuBar);

    Container contentPane = frame.getContentPane();
    contentPane.add(toolbar, BorderLayout.SOUTH);
    contentPane.add(new ActionButton(printAction), BorderLayout.CENTER);
    contentPane.add(buttonPanel, BorderLayout.NORTH);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
