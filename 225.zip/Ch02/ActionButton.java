import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.beans.*;

public class ActionButton extends JButton {

  class OurPropertyChangeListener implements PropertyChangeListener {
    public void propertyChange(PropertyChangeEvent propertyChangeEvent) {
      String propertyName = propertyChangeEvent.getPropertyName();
      if (propertyName.equals(Action.NAME)) {
        String text = (String)propertyChangeEvent.getNewValue();
        setText(text);
      } else if (propertyName.equals(Action.SMALL_ICON)) {
        Icon icon = (Icon)propertyChangeEvent.getNewValue();
        setIcon(icon);
      } else if (propertyName.equals(Action.SHORT_DESCRIPTION)) {
        String text = (String)propertyChangeEvent.getNewValue();
        setToolTipText(text);
      } else if (propertyName.equals("enabled")) {
        Boolean enabledState = (Boolean)propertyChangeEvent.getNewValue();
        setEnabled(enabledState.booleanValue());
      } 
    }
  }

  private Action action;
  PropertyChangeListener propertyChangeListener;

  public ActionButton() {
  }

  public ActionButton(Action action) {
    setAction(action);
  }

  public void setAction(Action newValue) {

    // Disconnect current action;
    if ((action != null) && (propertyChangeListener != null)) {
      action.removePropertyChangeListener(propertyChangeListener);
      removeActionListener(action);
    }

    action = newValue;

    if (action == null) {
      setText("");
      setIcon(null);
    } else {
      setText((String)action.getValue(Action.NAME));
      setIcon((Icon)action.getValue(Action.SMALL_ICON));
      setEnabled(action.isEnabled());
      String toolTipText = (String)action.getValue(Action.SHORT_DESCRIPTION);
      if (toolTipText != null) {
        setToolTipText(toolTipText);
      }
      addActionListener(action);
      if (propertyChangeListener == null) {
        propertyChangeListener = new OurPropertyChangeListener();
      }
      action.addPropertyChangeListener(propertyChangeListener);
    }
  }
}