import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class NextComponentSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Next Component Sample");

    Container contentPane = frame.getContentPane();
    contentPane.setLayout(new GridLayout(3,3));

    int COUNT = 9;
    JButton components[] = new JButton[COUNT];

    for (int i=0; i<COUNT; i++) {
      JButton button = new JButton("" + (i+1));
      components[i] = button;
      contentPane.add(button);
    }

    // Reverse tab order
    for (int i=0; i<COUNT; i++) {
      System.out.println(components[i].getText() + ":" + components[(i+COUNT-1) % COUNT].getText());
      components[i].setNextFocusableComponent(components[(i+COUNT-1) % COUNT]);
    }

    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
