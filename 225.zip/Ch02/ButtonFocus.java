import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ButtonFocus {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Action Sample");

    JButton focusButton = new JButton("Focused");
    JButton notFocusButton = new JButton("Not Focused");


    Container contentPane = frame.getContentPane();
    contentPane.setLayout(new FlowLayout());
    contentPane.add(focusButton);
    contentPane.add(notFocusButton);
    frame.setSize(300, 100);
    frame.setVisible(true);
  }
}
