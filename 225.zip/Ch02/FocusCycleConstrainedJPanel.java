import javax.swing.*;
public class FocusCycleConstrainedJPanel extends JPanel {
  public boolean isFocusCycleRoot() {
    return true;
  }
}
