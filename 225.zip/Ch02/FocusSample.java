import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FocusSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Focus Sample");

    ActionListener actionListener = new ActionFocusMover();
    MouseListener  mouseListener  = new MouseEnterFocusMover();

    Container contentPane = frame.getContentPane();
    contentPane.setLayout(new GridLayout(3,3));
    for (int i=1; i<10; i++) {
      JButton button = new JButton("" + i);
      button.addActionListener(actionListener);
      button.addMouseListener(mouseListener);
      if ((i%2) != 0) { // odd - enabled by default
        button.setRequestFocusEnabled(false);
      }
      contentPane.add(button);
    }

    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
