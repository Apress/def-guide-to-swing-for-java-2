import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;

public class BoundSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Button Sample");
    final JButton button1 = new JButton("Select Me");
    final JButton button2 = new JButton("No Select Me");

    // Define ActionListener
    ActionListener actionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        JButton button = (JButton)actionEvent.getSource();
        int red = (int)(Math.random()*255);
        int green = (int)(Math.random()*255);
        int blue = (int)(Math.random()*255);
        button.setBackground(new Color(red, green, blue));
      }
    };

    // Define PropertyChangeListener
    PropertyChangeListener propertyChangeListener = new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent propertyChangeEvent) {
        String property = propertyChangeEvent.getPropertyName();
        if ("background".equals(property)) {
          button2.setBackground((Color)propertyChangeEvent.getNewValue());
        }
      } 
    };

    // Attach Listeners
    button1.addActionListener(actionListener);
    button1.addPropertyChangeListener(propertyChangeListener);
    button2.addActionListener(actionListener);
 
    Container contentPane = frame.getContentPane();
    contentPane.add(button1, BorderLayout.NORTH);
    contentPane.add(button2, BorderLayout.SOUTH);
    frame.setSize(300, 100);
    frame.setVisible(true);
  }
}
