import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VerifierSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Verifier Sample");
    JTextField textField1 = new JTextField();
    JTextField textField2 = new JTextField();
    JTextField textField3 = new JTextField();

    InputVerifier verifier = new InputVerifier() {
      public boolean verify(JComponent comp) {
        boolean returnValue;
        JTextField textField = (JTextField)comp;
        try {
          Integer.parseInt(textField.getText());
          returnValue = true;
        } catch (NumberFormatException e) {
          returnValue = false;
        }
        return returnValue;
      }
    };

    textField1.setInputVerifier(verifier);
    textField3.setInputVerifier(verifier);

    Container contentPane = frame.getContentPane();
    contentPane.add(textField1, BorderLayout.NORTH);
    contentPane.add(textField2, BorderLayout.CENTER);
    contentPane.add(textField3, BorderLayout.SOUTH);
    frame.setSize(300, 100);
    frame.setVisible(true);
  }
}