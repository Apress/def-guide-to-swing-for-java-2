import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class KeyTextTester  {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Key Text Sample");
    KeyTextComponent keyTextComponent = new KeyTextComponent();
    final JTextField textField = new JTextField();

    ActionListener actionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        String keyText = actionEvent.getActionCommand();
        textField.setText(keyText);
      }
    };
    keyTextComponent.addActionListener(actionListener);

    Container contentPane = frame.getContentPane();
    contentPane.add(keyTextComponent, BorderLayout.CENTER);
    contentPane.add(textField, BorderLayout.SOUTH);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}