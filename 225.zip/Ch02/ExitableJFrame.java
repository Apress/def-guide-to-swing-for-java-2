import javax.swing.*;

public class ExitableJFrame extends JFrame {
  private int returnCode = 0;
  public ExitableJFrame () {
  }
  public ExitableJFrame (String title) {
    super (title);
  }
  protected void frameInit() {
    super.frameInit();
    setDefaultCloseOperation(EXIT_ON_CLOSE);
  }
}