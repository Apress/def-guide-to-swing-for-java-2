import java.awt.*;
import java.awt.event.*;
public class ActionFocusMover implements ActionListener {
  public void actionPerformed(ActionEvent actionEvent) {
    Object source = actionEvent.getSource();
    if (source instanceof Component) {
      Component component = (Component)source;
      component.transferFocus();
    }
  }
}
