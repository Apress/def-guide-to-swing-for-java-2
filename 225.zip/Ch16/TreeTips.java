import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.util.*;

public class TreeTips {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Tree Tips");
    Properties props = System.getProperties();
    JTree tree = new JTree(props);
    ToolTipManager.sharedInstance().registerComponent(tree);
    TreeCellRenderer renderer = new ToolTipTreeCellRenderer(props);
    tree.setCellRenderer(renderer);
    JScrollPane scrollPane = new JScrollPane(tree);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
