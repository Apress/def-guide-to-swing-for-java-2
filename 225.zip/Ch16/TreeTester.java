import java.awt.*;
import javax.swing.*;

public class TreeTester {
  public static void main (String args[]) {
    JFrame f = new ExitableJFrame("Tree Dragging Tester");
    DndTree tree1 = new DndTree();
    JScrollPane leftPane = new JScrollPane(tree1);
    DndTree tree2 = new DndTree();
    JScrollPane rightPane = new JScrollPane(tree2);
    JSplitPane splitPane = 
      new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPane, rightPane);
    f.getContentPane().add (splitPane,  BorderLayout.CENTER);
    f.setSize (300, 200);
    f.setVisible (true);
  }
}
