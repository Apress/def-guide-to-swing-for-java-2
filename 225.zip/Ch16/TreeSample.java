import javax.swing.*;
import java.awt.*;

public class TreeSample {
  public static void main(String args[]) {
    String title = (args.length==0 ? "JTree Sample" : args[0]);
    JFrame frame = new ExitableJFrame(title);
//UIManager.put("Tree.openIcon", new DiamondIcon(Color.red, false));

UIManager.put("Tree.line", Color.green);
    JTree tree = new JTree();
tree.putClientProperty("JTree.lineStyle", "Horizontal");
tree.setSelectionModel(null);
    JScrollPane scrollPane = new JScrollPane(tree);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
