import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.util.*;

public class TreeUtilSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("DynamicUtilTreeNode Hashtable");

    DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");

    Hashtable hashtable = new Hashtable();
    hashtable.put ("One", args);
    hashtable.put ("Two", new String[]{"Mercury", "Venus", "Mars"});
    Hashtable innerHashtable = new Hashtable();
    Properties props = System.getProperties();
    innerHashtable.put (props, props);
    innerHashtable.put ("Two", new String[]{"Mercury", "Venus", "Mars"});
    hashtable.put ("Three", innerHashtable);

    JTree.DynamicUtilTreeNode.createChildren(root, hashtable);

    JTree tree = new JTree(root);

    JScrollPane scrollPane = new JScrollPane(tree);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
