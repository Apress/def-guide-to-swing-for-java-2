import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

public class TreeSelectionRow {
  public static void main(String args[]) {
    String title = (args.length==0 ? "JTree Sample" : args[0]);
    JFrame frame = new ExitableJFrame(title);
    JTree tree = new JTree();
    TreeSelectionListener treeSelectionListener = new TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent treeSelectionEvent) {
        JTree treeSource = (JTree)treeSelectionEvent.getSource();
        System.out.println ("Min: " + treeSource.getMinSelectionRow());
        System.out.println ("Max: " + treeSource.getMaxSelectionRow());
        System.out.println ("Lead: " + treeSource.getLeadSelectionRow());
        System.out.println ("Row: " + treeSource.getSelectionRows()[0]);
      }
    };
    tree.addTreeSelectionListener(treeSelectionListener);
   
    JScrollPane scrollPane = new JScrollPane(tree);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
//    frame.setSize(300, 300);
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
