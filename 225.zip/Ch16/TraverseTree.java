import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.*;
import java.util.*;

public class TraverseTree {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Traverse Tree");
    Object footballNodes[] = {"Giants", "Jets", "Bills"};
    Vector footballVector = new NamedVector("Football", footballNodes);
    Object newYorkNodes[] = {"Mets", "Yankees", "Rangers", footballVector};
    Vector newYorkVector = new NamedVector("New York", newYorkNodes);
    Object bostonNodes[] = {"Red Sox", "Celtics", "Bruins"};
    Vector bostonVector = new NamedVector("Boston", bostonNodes);
    Object denverNodes[] = {"Rockies", "Avalanche", "Broncos"};
    Vector denverVector = new NamedVector("Denver", denverNodes);
    Object rootNodes[] = {newYorkVector, bostonVector, denverVector};
    Vector rootVector = new NamedVector("Root", rootNodes);
    JTree tree = new JTree(rootVector);
    tree.setRootVisible(true);
    TreeModel model = tree.getModel();
    Object rootObject = model.getRoot();
    if ((rootObject != null) && (rootObject instanceof DefaultMutableTreeNode)) {
      DefaultMutableTreeNode root = (DefaultMutableTreeNode)rootObject;
//    printDescendents(root);
      Enumeration breadth = root.breadthFirstEnumeration();
      Enumeration depth = root.depthFirstEnumeration();
      Enumeration preOrder = root.preorderEnumeration();
      printEnumeration(breadth, "Breadth");
//      printEnumeration(depth, "Depth");
//      printEnumeration(preOrder, "Pre");
    }

    TreeSelectionListener treeSelectionListener = new TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent treeSelectionEvent) {
        JTree treeSource = (JTree)treeSelectionEvent.getSource();
        TreePath path = treeSource.getSelectionPath();
        System.out.println(path);
        System.out.println(path.getPath());
        System.out.println(path.getParentPath());
        System.out.println(((DefaultMutableTreeNode)path.getLastPathComponent()).getUserObject());
        System.out.println(path.getPathCount());
      }
    };
    tree.addTreeSelectionListener(treeSelectionListener);

    JScrollPane scrollPane = new JScrollPane(tree);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 400);
    frame.setVisible(true);
  }
  private static void printEnumeration(Enumeration enum, String label) {
    System.out.println("-----" + label + "-----");
    while(enum.hasMoreElements()) {
      System.out.println(enum.nextElement());
    }
  }
  public static void printDescendents(TreeNode root) {
    System.out.println(root);
    Enumeration children = root.children();
    if (children != null) {
      while(children.hasMoreElements()) {
       printDescendents((TreeNode)children.nextElement());
      }
    }
  }
}
