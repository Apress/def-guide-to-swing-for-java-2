import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;

public class NodeTreeSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Manual Nodes");
    DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");
    DefaultMutableTreeNode mercury = new DefaultMutableTreeNode("Mercury");
    root.add(mercury);
    DefaultMutableTreeNode venus = new DefaultMutableTreeNode("Venus");
    root.add(venus);
    DefaultMutableTreeNode mars = new DefaultMutableTreeNode("Mars");
    root.add(mars);
    JTree tree = new JTree(root);
    JScrollPane scrollPane = new JScrollPane(tree);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
