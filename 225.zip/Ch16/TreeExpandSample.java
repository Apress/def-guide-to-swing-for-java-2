import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.*;

public class TreeExpandSample {
  public static void main(String args[]) {
    String title = ("JTree Expand Sample");
    JFrame frame = new ExitableJFrame(title);
    JTree tree = new JTree();
    TreeWillExpandListener treeWillExpandListener = new TreeWillExpandListener() {
      public void treeWillCollapse(TreeExpansionEvent treeExpansionEvent) throws ExpandVetoException {
        TreePath path = treeExpansionEvent.getPath();
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)path.getLastPathComponent();
        String data = node.getUserObject().toString();
        if (data.equals("colors")) {
          throw new ExpandVetoException(treeExpansionEvent);
        }
      }
      public void treeWillExpand(TreeExpansionEvent treeExpansionEvent) throws ExpandVetoException {
        TreePath path = treeExpansionEvent.getPath();
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)path.getLastPathComponent();
        String data = node.getUserObject().toString();
        if (data.equals("sports")) {
          throw new ExpandVetoException(treeExpansionEvent);
        }
      }
    };
    tree.addTreeWillExpandListener(treeWillExpandListener);
    JScrollPane scrollPane = new JScrollPane(tree);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
