import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.util.*;

public class BookTree {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Book Tree");
    Book javaBooks[] = {
      new Book("Core Java 2 Fundamentals", "Cornell/Horstmann", 42.99f),
      new Book("Taming Java Threads", "Holub", 34.95f),
      new Book("JavaServer  Pages", "Pekowsky", 39.95f)
    };
    Book htmlBooks[] = {
      new Book("Dynamic HTML", "Goodman", 39.95f),
      new Book("HTML 4 Bible", "Pfaffenberger/Gutzman", 49.99f)
    };
    Vector javaVector = new NamedVector("Java Books", javaBooks);
    Vector htmlVector = new NamedVector("HTML Books", htmlBooks);
    Object rootNodes[] = {javaVector, htmlVector};
    Vector rootVector = new NamedVector("Root", rootNodes);
    JTree tree = new JTree(rootVector);
    TreeCellRenderer renderer = new BookCellRenderer();
    tree.setCellRenderer(renderer);
    JScrollPane scrollPane = new JScrollPane(tree);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 300);
    frame.setVisible(true);
  }
}
