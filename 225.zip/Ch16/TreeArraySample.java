import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.util.*;

public class TreeArraySample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("JTreeSample");

    Vector oneVector = new NamedVector("One", args);
    Vector twoVector = new NamedVector("Two", new String[]{"Mercury", "Venus", "Mars"});
    Vector threeVector = new NamedVector("Three");
    threeVector.add(System.getProperties());
    threeVector.add(twoVector);
    Object rootNodes[] = {oneVector, twoVector, threeVector};
    Vector rootVector = new NamedVector("Root", rootNodes);
    JTree tree = new JTree(rootVector);

    JScrollPane scrollPane = new JScrollPane(tree);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
//    frame.getContentPane().add(tree, BorderLayout.CENTER);
    frame.setSize(300, 300);
    frame.setVisible(true);
  }
}
