import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;

public class EditLeafSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Editable Tree");
    JTree tree = new JTree();
    tree.setEditable(true);

    DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer)tree.getCellRenderer();
    TreeCellEditor editor = new LeafCellEditor(tree, renderer);
    tree.setCellEditor(editor);

    JScrollPane scrollPane = new JScrollPane(tree);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
