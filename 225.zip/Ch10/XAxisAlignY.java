import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class XAxisAlignY {
  private static Container makeIt(String title, float alignment) {
    String labels[] = {"--", "--", "--"};

    JPanel container = new JPanel();
    container.setBorder(BorderFactory.createTitledBorder(title));
    BoxLayout layout = new BoxLayout(container, BoxLayout.X_AXIS);
    container.setLayout(layout);

    for (int i=0,n=labels.length; i<n; i++) {
      JButton button = new JButton(labels[i]);
      button.setAlignmentY(alignment);
      container.add(button);
    }
    return container;
  }

  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Alignment Example");

    Container panel1 = makeIt("Top", Component.TOP_ALIGNMENT);
    Container panel2 = makeIt("Center", Component.CENTER_ALIGNMENT);
    Container panel3 = makeIt("Bottom", Component.BOTTOM_ALIGNMENT);

    Container contentPane = frame.getContentPane();
    contentPane.setLayout(new GridLayout(1, 3));
    contentPane.add(panel1);
    contentPane.add(panel2);
    contentPane.add(panel3);

    frame.setSize(423, 171);
    frame.setVisible(true);
  }
}
