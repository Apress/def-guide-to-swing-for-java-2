import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MnemonicSample {

  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Mnemonics");

    Container content = frame.getContentPane();
    content.setLayout(new GridLayout(1, 0));

    JButton button1 = new JButton("Warning");
    button1.setMnemonic(KeyEvent.VK_W);
    content.add(button1);

    JButton button2 = new JButton("Warning");
    button2.setMnemonic(KeyEvent.VK_H);
    content.add(button2);

    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
