import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.util.*;

public class TreeLines {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Tree Lines");

    Container content = frame.getContentPane();
    Box box = Box.createHorizontalBox();

    JTree tree1 = new JTree();
    tree1.putClientProperty("JTree.lineStyle", "Angled");
    JScrollPane scrollPane1 = new JScrollPane(tree1);
    tree1.setAutoscrolls(true);

    JTree tree2 = new JTree();
    JScrollPane scrollPane2 = new JScrollPane(tree2);

    box.add(scrollPane1, BorderLayout.WEST);
    box.add(scrollPane2, BorderLayout.EAST);

    frame.getContentPane().add(box, BorderLayout.CENTER);
    frame.setSize(300, 240);
    frame.setVisible(true);
  }
}
