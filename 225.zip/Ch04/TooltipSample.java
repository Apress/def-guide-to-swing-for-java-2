import javax.swing.*;
import java.awt.*;

public class TooltipSample {

  public static void main(String args[]) {
    String title = (args.length==0 ? "Tooltip Sample" : args[0]);
    JFrame frame = new ExitableJFrame(title);

    Container container = frame.getContentPane();
    JPanel panel = new JPanel();
    panel.setToolTipText("<HtMl>Tooltip<br>Message");
    container.add(panel, BorderLayout.CENTER);

JButton button = new JButton("Hello World") {
  public JToolTip createToolTip() {
    JToolTip tip = super.createToolTip();
//    tip.setBackground(Color.yellow);
//    tip.setForeground(Color.green);
    return tip;
  }
  public boolean contains(int x, int y) {
    if (x < 100) {
      setToolTipText("Got Green Eggs?");
    } else {
      setToolTipText("Got Ham?");
    }
    return super.contains(x, y);
  }
};
button.setToolTipText("Hello World");
frame.getContentPane().add(button, BorderLayout.NORTH);

    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
