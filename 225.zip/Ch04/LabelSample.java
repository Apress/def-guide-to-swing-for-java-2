import javax.swing.*;
import java.awt.*;

public class LabelSample {

  public static void main(String args[]) {
    String title = (args.length==0 ? "JLabel Sample" : args[0]);
    JFrame frame = new ExitableJFrame(title);

    Container content = frame.getContentPane();
    content.setLayout(new GridLayout(2, 2));

    JLabel label1 = new JLabel("Text Label");
    content.add(label1);

    Icon warnIcon = new ImageIcon("Warn.gif");
    JLabel label2 = new JLabel(warnIcon);
    content.add(label2);

    JLabel label3 = new JLabel("Warning", warnIcon, JLabel.CENTER);
    content.add(label3);

    String htmlLabel = "<html><sup>HTML</sup> <sub><em>Label</em></sub><br>" +
      "<font color=\"#FF0080\"><u>Multi-line</u></font>";
    JLabel label4 = new JLabel(htmlLabel);
    content.add(label4);

    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
