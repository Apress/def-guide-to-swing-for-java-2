import javax.swing.*;
import java.awt.*;

public class LabelIcon {

  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Label Icon");

    Container content = frame.getContentPane();

    Icon icon = new DiamondIcon(Color.red, true, 25, 25);
    JLabel label1 = new JLabel(icon);
    content.add(label1);

    frame.setSize(200, 100);
    frame.setVisible(true);
  }
}
