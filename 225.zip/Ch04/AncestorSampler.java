import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

public class AncestorSampler {
  public static void main (String args[]) {
    JFrame f = new ExitableJFrame("Ancestor Sampler");
    AncestorListener ancestorListener = new AncestorListener() {
      public void ancestorAdded(AncestorEvent ancestorEvent) {
        System.out.println ("Added");
      }
      public void ancestorMoved(AncestorEvent ancestorEvent) {
        System.out.println ("Moved");
      }
      public void ancestorRemoved(AncestorEvent ancestorEvent) {
        System.out.println ("Removed");
      }
    };
    f.getRootPane().addAncestorListener(ancestorListener);
    f.getRootPane().setVisible(false);
    f.getRootPane().setVisible(true);
    f.setSize (300, 200);
    f.setVisible (true);
  }
}