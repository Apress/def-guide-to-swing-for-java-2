import java.awt.*;
import javax.swing.*;

public class OvalPanel extends JPanel {

  Color color;

  public OvalPanel() {
    this(Color.black);
  }
  public OvalPanel(Color color) {
    this.color = color;
  }
  public void paintComponent(Graphics g) {
    int width = getWidth();
    int height = getHeight();
    g.setColor(color);
    g.drawOval(0, 0, width, height);
  }

  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Oval Sample");

    Container content = frame.getContentPane();
    content.setLayout(new GridLayout(2, 2));

    Color colors[] = {Color.red, Color.blue, Color.green, Color.yellow};
    for (int i=0; i<4; i++) {
      OvalPanel panel = new OvalPanel(colors[i]);
      content.add(panel);
    }

    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
