import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

public class LabelFor {
  public static void main (String args[]) {
    JFrame f = new ExitableJFrame("LabelFor Sample");
    Container content = f.getContentPane();
    JLabel label = new JLabel("Username");
    JTextField textField = new JTextField();
    label.setDisplayedMnemonic(KeyEvent.VK_U);
    label.setLabelFor(textField);
    Container box = Box.createHorizontalBox();
    box.add(label);
    box.add(textField);
    content.add(box, BorderLayout.NORTH);
    content.add(new JButton("Submit"), BorderLayout.SOUTH);
    f.setSize (300, 200);
    f.setVisible (true);
  }
}