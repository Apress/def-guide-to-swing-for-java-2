import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;  

public class AButton {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Sample Borders");
    Border border = BorderFactory.createTitledBorder("Pizza Toppings");
    JButton button = new JButton ("Help");
    button.setBorder(null);
//    button.updateUI();
    Container contentPane = frame.getContentPane();
    contentPane.add(button, BorderLayout.SOUTH);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
