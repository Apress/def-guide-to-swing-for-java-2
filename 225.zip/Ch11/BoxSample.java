import javax.swing.*;
import java.awt.*;

public class BoxSample {
  public static void main(String args[]) {
    JFrame verticalFrame = new ExitableJFrame("Vertical");
    Box verticalBox = Box.createVerticalBox();
    verticalBox.add(new JLabel("Top"));
    verticalBox.add(new JTextField("Middle"));
    verticalBox.add(new JButton("Bottom"));
    verticalFrame.getContentPane().add(verticalBox, BorderLayout.CENTER);
    verticalFrame.setSize(150, 150);
    verticalFrame.setVisible(true);

    JFrame horizontalFrame = new ExitableJFrame("Horizontal");
    Box horizontalBox = Box.createHorizontalBox();
    horizontalBox.add(new JLabel("Left"));
    horizontalBox.add(new JTextField("Middle"));
    horizontalBox.add(new JButton("Right"));
    horizontalFrame.getContentPane().add(horizontalBox, BorderLayout.CENTER);
    horizontalFrame.setSize(150, 150);
    horizontalFrame.setVisible(true);
  }
}
