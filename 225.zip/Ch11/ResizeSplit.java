import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ResizeSplit {
  public static void main(String args[]) {
    String title = (args.length==0 ? "Resize Split" : args[0]);

    final JFrame vFrame = new ExitableJFrame(title);
    JButton topButton = new JButton("Top");
    JButton bottomButton = new JButton("Bottom");
    final JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
    splitPane.setTopComponent(topButton);
    splitPane.setBottomComponent(bottomButton);
    ActionListener oneActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        splitPane.setResizeWeight(1.0);
        vFrame.setSize(300, 250);
        vFrame.validate();
      }
    };
    bottomButton.addActionListener(oneActionListener);

    ActionListener anotherActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        splitPane.setResizeWeight(0.5);
        vFrame.setSize(300, 250);
        vFrame.validate();
      }
    };
    topButton.addActionListener(anotherActionListener);
    vFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    vFrame.setSize(300, 150);
    vFrame.setVisible(true);

  }
}
