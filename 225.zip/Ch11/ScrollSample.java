import javax.swing.*;
import java.awt.*;

public class ScrollSample {
  public static void main(String args[]) {
    String title = (args.length==0 ? "JScrollPane Sample" : args[0]);
    JFrame frame = new ExitableJFrame(title);
    Icon icon = new ImageIcon("dog.jpg");
    JLabel dogLabel = new JLabel(icon);
    JScrollPane scrollPane = new JScrollPane();
    scrollPane.setViewportView(dogLabel);
//    scrollPane.getViewport().setView(dogLabel);
    frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
