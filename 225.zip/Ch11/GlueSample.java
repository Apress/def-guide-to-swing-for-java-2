import javax.swing.*;
import java.awt.*;

public class GlueSample {
  public static void main(String args[]) {
    Box horizontalBox;
    JPanel panel;
    JFrame frame = new ExitableJFrame("Horizontal Glue");
    Container contentPane = frame.getContentPane();
    contentPane.setLayout(new GridLayout(0,1));

    horizontalBox = Box.createHorizontalBox();
    horizontalBox.add(Box.createGlue());
    horizontalBox.add(new JButton("Left"));
    horizontalBox.add(new JButton("Middle"));
    horizontalBox.add(new JButton("Right"));
    panel = new JPanel(new BorderLayout());
    panel.add(horizontalBox);
    panel.setBorder(BorderFactory.createTitledBorder("Beginning Glue"));
    contentPane.add(panel);

    horizontalBox = Box.createHorizontalBox();
    horizontalBox.add(new JButton("Left"));
    horizontalBox.add(Box.createGlue());
    horizontalBox.add(new JButton("Middle"));
    horizontalBox.add(Box.createGlue());
    horizontalBox.add(new JButton("Right"));
    panel = new JPanel(new BorderLayout());
    panel.add(horizontalBox);
    panel.setBorder(BorderFactory.createTitledBorder("2 Middle Glues"));
    contentPane.add(panel);

    horizontalBox = Box.createHorizontalBox();
    horizontalBox.add(Box.createGlue());
    horizontalBox.add(new JButton("Left"));
    horizontalBox.add(new JButton("Middle"));
    horizontalBox.add(new JButton("Right"));
    horizontalBox.add(Box.createGlue());
    panel = new JPanel(new BorderLayout());
    panel.add(horizontalBox);
    panel.setBorder(BorderFactory.createTitledBorder("Beginning/End Glues"));
    contentPane.add(panel);

    horizontalBox = Box.createHorizontalBox();
    horizontalBox.add(new JButton("Left"));
    horizontalBox.add(new JButton("Middle"));
    horizontalBox.add(new JButton("Right"));
    panel = new JPanel(new BorderLayout());
    horizontalBox.add(Box.createGlue());
    panel.add(horizontalBox);
    panel.setBorder(BorderFactory.createTitledBorder("End Glue"));
    contentPane.add(panel);

    frame.setSize(300, 300);
    frame.setVisible(true);
  }
}
