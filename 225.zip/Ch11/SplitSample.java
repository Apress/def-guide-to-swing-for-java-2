import javax.swing.*;
import java.awt.*;

public class SplitSample {
  public static void main(String args[]) {
    JFrame vFrame = new ExitableJFrame("JSplitPane Sample");
    JSplitPane vSplitPane = new JSplitPane();
    vSplitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
    vFrame.getContentPane().add(vSplitPane, BorderLayout.CENTER);
    vFrame.setSize(300, 150);
    vFrame.setVisible(true);

    JFrame hFrame = new ExitableJFrame("JSplitPane Sample");
    JSplitPane hSplitPane = new JSplitPane();
    hFrame.getContentPane().add(hSplitPane, BorderLayout.CENTER);
    hFrame.setSize(300, 150);
    hFrame.setVisible(true);
  }
}
