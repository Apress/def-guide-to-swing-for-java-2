import javax.swing.*;
import java.awt.*;

public class ViewSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("JViewport Sample");
    Icon icon = new ImageIcon("dog.jpg");
    JLabel dogLabel = new JLabel(icon);
    JViewport viewport = new JViewport();
    viewport.setView(dogLabel);
    frame.getContentPane().add(viewport, BorderLayout.CENTER);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
