import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

public class TabSample {
  static Color colors[] = {Color.red, Color.orange, Color.yellow, Color.green, Color.blue, Color.magenta};
  static void add(JTabbedPane tabbedPane, String label) {
    int count = tabbedPane.getTabCount();
    JButton button = new JButton(label);
    button.setBackground(colors[count]);
    tabbedPane.addTab(label, new DiamondIcon(colors[count]), button, label);
  }

  public static void main(String args[]) {
    String title = (args.length==0 ? "Tabbed Pane Sample" : args[0]);
    JFrame frame = new ExitableJFrame(title);

    JTabbedPane tabbedPane = new JTabbedPane();
    String titles[] = {"General", "Security", "Content", "Connection", "Programs", "Advanced"};
    for (int i=0, n=titles.length; i<n; i++) {
      add(tabbedPane, titles[i]);
    }

    ChangeListener changeListener = new ChangeListener() {
      public void stateChanged(ChangeEvent changeEvent) {
        JTabbedPane sourceTabbedPane = (JTabbedPane)changeEvent.getSource();
        int index = sourceTabbedPane.getSelectedIndex();
        System.out.println ("Tab changed to: " + sourceTabbedPane.getTitleAt(index));
      }
    };
    tabbedPane.addChangeListener(changeListener);

    Container contentPane = frame.getContentPane();
    contentPane.add(tabbedPane, BorderLayout.CENTER);
    frame.setSize(400, 150);
    frame.setVisible(true);
  }
}
