import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VerticalSplit {
  public static void main(String args[]) {
    JFrame vFrame = new ExitableJFrame("Vertical Split");
    JComponent leftButton = new JButton("Left");
    JComponent rightButton = new JButton("Right");
    final JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
    splitPane.setOneTouchExpandable(true);
    splitPane.setLeftComponent(leftButton);
    splitPane.setRightComponent(rightButton);
    ActionListener oneActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        splitPane.resetToPreferredSizes();
      }
    };
    ((JButton)rightButton).addActionListener(oneActionListener);
    ActionListener anotherActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        splitPane.setDividerLocation(10);
        splitPane.setContinuousLayout(true);
      }
    };
    ((JButton)leftButton).addActionListener(anotherActionListener);
    vFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
    vFrame.setSize(300, 150);
    vFrame.setVisible(true);

  }
}
