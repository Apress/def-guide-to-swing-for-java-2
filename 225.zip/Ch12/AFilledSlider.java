import javax.swing.*;
import java.awt.*;	

public class AFilledSlider {
  public static void main(String args[]) {
    JFrame f = new ExitableJFrame("Filled Slider");
    JSlider js1 = new JSlider ();
    js1.putClientProperty("JSlider.isFilled", Boolean.TRUE);
    JSlider js2 = new JSlider ();
    js2.putClientProperty("JSlider.isFilled", Boolean.FALSE);
    Container c = f.getContentPane();
    c.add (js1, BorderLayout.NORTH);
    c.add (js2, BorderLayout.SOUTH);
    f.setSize (300, 200);
    f.setVisible (true);
  }
}
