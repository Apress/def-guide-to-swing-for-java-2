import javax.swing.*;
import java.awt.*;	
import java.util.Hashtable;

public class SampleSliders {
  public static void main(String args[]) {
    String title = (args.length==0 ? "Sample Slider" : args[0]);
    JFrame f = new ExitableJFrame(title);
    JSlider js1 = new JSlider ();
    js1.putClientProperty("JSlider.isFilled", Boolean.TRUE);
    JSlider js2 = new JSlider ();
    js2.setMajorTickSpacing (25);
    js2.setPaintTicks (true);
    js2.setSnapToTicks(true);
    JSlider js3 = new JSlider (JSlider.VERTICAL);
    js3.setPaintTrack (false);
    js3.setMinorTickSpacing (5);
    js3.setMajorTickSpacing (10);
    js3.setPaintTicks (true);
    js3.setPaintLabels (true);
    js3.setSnapToTicks(true);
    JSlider js4 = new JSlider (JSlider.VERTICAL);
    Hashtable table = new Hashtable();
    table.put (new Integer (0), new JLabel(new DiamondIcon(Color.red)));
    table.put (new Integer (10), new JLabel("Ten"));
    table.put (new Integer (25), new JLabel("Twenty-Five"));
    table.put (new Integer (34), new JLabel("Thirty-Four"));
    table.put (new Integer (52), new JLabel("Fifty-Two"));
    table.put (new Integer (70), new JLabel("Seventy"));
    table.put (new Integer (82), new JLabel("Eighty-Two"));
    table.put (new Integer (100), new JLabel(new DiamondIcon(Color.black)));
    js4.setLabelTable (table);
    js4.setPaintLabels (true);
    js4.setSnapToTicks(true);
    Container c = f.getContentPane();
    c.add (js1, BorderLayout.NORTH);
    c.add (js2, BorderLayout.SOUTH);
    c.add (js3, BorderLayout.WEST);
    c.add (js4, BorderLayout.EAST);
    f.setSize (300, 200);
    f.setVisible (true);
  }
}
