import javax.swing.*;
import java.awt.*;	
import java.util.Hashtable;

public class InvertedSliders {
  public static void main(String args[]) {
    JFrame f = new ExitableJFrame("Inverted Sliders");
    JSlider js1 = new JSlider ();
    js1.setMajorTickSpacing (10);
    js1.setPaintTicks (true);
    js1.setPaintLabels (true);
    JSlider js2 = new JSlider ();
    js2.setInverted(true);
    js2.setMajorTickSpacing (10);
    js2.setPaintTicks (true);
    js2.setPaintLabels (true);
    JSlider js3 = new JSlider (JSlider.VERTICAL);
    js3.setPaintTrack (false);
    js3.setMajorTickSpacing (10);
    js3.setPaintTicks (true);
    js3.setPaintLabels (true);
    JSlider js4 = new JSlider (JSlider.VERTICAL);
    js4.setInverted(true);
    js4.setMajorTickSpacing (10);
    js4.setPaintTicks (true);
    js4.setPaintLabels (true);
    Container c = f.getContentPane();
    c.add (js1, BorderLayout.NORTH);
    c.add (js2, BorderLayout.SOUTH);
    c.add (js3, BorderLayout.EAST);
    c.add (js4, BorderLayout.WEST);
    f.setSize (300, 250);
    f.setVisible (true);
  }
}
