import javax.swing.*;
import java.awt.*;	
import javax.swing.plaf.ColorUIResource;

public class ScrollBarPieces {
  public static void main(String args[]) {
    JScrollBar oneJScrollBar = new JScrollBar (JScrollBar.HORIZONTAL);
    String title = (args.length==0 ? "ScrollBar Sample" : args[0]);
    JFrame frame = new ExitableJFrame(title);
    Container contentPane = frame.getContentPane();
    contentPane.add (oneJScrollBar, BorderLayout.NORTH);
    frame.setSize(200, 44);
    frame.setVisible (true);
  }
}
