import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;	

public class ScrollSlider {
  public static void main(String args[]) {
    JFrame f = new ExitableJFrame("Change Slider");
    JSlider aJSlider = new JSlider (JSlider.HORIZONTAL, 0, 1000, 500);
    ChangeListener aChangeListener = new BoundedChangeListener();
    aJSlider.addChangeListener(aChangeListener);
    Container c = f.getContentPane();
    c.add (aJSlider, BorderLayout.SOUTH);
    f.setSize (300, 200);
    f.setVisible (true);
  }
}
