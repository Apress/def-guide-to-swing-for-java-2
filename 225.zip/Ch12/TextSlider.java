import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class TextSlider extends JPanel {
  private JTextField textField;
  private JScrollBar scrollBar;
  public TextSlider() {
    setLayout (new BoxLayout (this, BoxLayout.Y_AXIS));
    textField = new JTextField();
    scrollBar = new JScrollBar(JScrollBar.HORIZONTAL);
    BoundedRangeModel brm = textField.getHorizontalVisibility();
    scrollBar.setModel (brm);
    add (textField);
    add (scrollBar);
  }
  public JTextField getTextField () {
    return textField;
  }
  public String getText() {
    return textField.getText();
  }
  public void addActionListener(ActionListener l) {
    textField.addActionListener(l);
  }
  public void removeActionListener(ActionListener l) {
    textField.removeActionListener(l);
  }
  public JScrollBar getScrollBar() {
    return scrollBar;
  }
  public static void main(String args[]) {
    JFrame f = new ExitableJFrame("Text Slider");
    final TextSlider ts = new TextSlider();
    ts.addActionListener (new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        System.out.println ("Text: " + ts.getText());
      }
    });
    Container c = f.getContentPane();
    c.add (ts, BorderLayout.NORTH);
    f.setSize(300, 200);
    f.setVisible (true);
  }
}
