import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;	

public class ChangeSlider {
  public static void main(String args[]) {
    JFrame f = new ExitableJFrame("Change Slider");
    JSlider aJSlider = new JSlider (JSlider.HORIZONTAL);
    ChangeListener aChangeListener = new BoundedChangeListener();
    BoundedRangeModel model = aJSlider.getModel();
    model.addChangeListener(aChangeListener);
    aJSlider.addChangeListener(aChangeListener);
    Container c = f.getContentPane();
    c.add (aJSlider, BorderLayout.SOUTH);
    f.setSize (300, 200);
    f.setVisible (true);
  }
}
