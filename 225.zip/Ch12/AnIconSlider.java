import javax.swing.*;
import javax.swing.plaf.*;
import java.awt.*;

public class AnIconSlider {
  public static void main(String args[]) {
    JFrame f = new ExitableJFrame("Icon Slider");
    Icon icon = new ImageIcon("logo.gif");
    UIDefaults defaults = UIManager.getDefaults();
    defaults.put("Slider.horizontalThumbIcon", icon);
    JSlider aJSlider = new JSlider ();
    aJSlider.setPaintTicks (true);
    Container c = f.getContentPane();
    c.add (aJSlider, BorderLayout.NORTH);
    f.setSize (300, 200);
    f.setVisible (true);
  }
}
