import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;  

public class FlatCheckBox {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Flat CheckBox Sample");
    JPanel panel = new JPanel(new GridLayout(0, 1));
    Border border = BorderFactory.createTitledBorder("Pizza Toppings");
    panel.setBorder(border);
    JCheckBox check = new JCheckBox("Anchovies");
    check.setBorderPaintedFlat(true);
    panel.add(check);
    check = new JCheckBox("Garlic");
    panel.add(check);
    check = new JCheckBox("Onions");
    check.setBorderPaintedFlat(true);
    panel.add(check);
    check = new JCheckBox("Pepperoni");
    panel.add(check);
    check = new JCheckBox("Spinach");
    check.setBorderPaintedFlat(true);
    panel.add(check);
    JButton button = new JButton ("Submit");
    Container contentPane = frame.getContentPane();
    contentPane.add(panel, BorderLayout.CENTER);
    contentPane.add(button, BorderLayout.SOUTH);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
