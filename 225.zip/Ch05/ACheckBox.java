import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;  

public class ACheckBox {
  public static void main(String args[]) {
    String title = (args.length==0 ? "CheckBox Sample" : args[0]);
    JFrame frame = new ExitableJFrame(title);
//    JFrame frame = new ExitableJFrame("CheckBox Sample");
    JPanel panel = new JPanel(new GridLayout(0, 1));
    Border border = BorderFactory.createTitledBorder("Pizza Toppings");
    panel.setBorder(border);
    JCheckBox check = new JCheckBox("Anchovies");
    panel.add(check);
    check = new JCheckBox("Garlic");
    panel.add(check);
    check = new JCheckBox("Onions");
    panel.add(check);
    check = new JCheckBox("Pepperoni");
    panel.add(check);
    check = new JCheckBox("Spinach");
    panel.add(check);
    JButton button = new JButton ("Submit");
    Container contentPane = frame.getContentPane();
    contentPane.add(panel, BorderLayout.CENTER);
    contentPane.add(button, BorderLayout.SOUTH);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
