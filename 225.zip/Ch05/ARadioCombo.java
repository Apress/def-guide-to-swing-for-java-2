import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;  

public class ARadioCombo {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Radio/Combo Example");
    JPanel panel = new JPanel(new GridLayout(0, 1));
    Border border = BorderFactory.createTitledBorder("Radio Buttons");
    panel.setBorder(border);
    ButtonGroup group = new ButtonGroup();
    JRadioButton aRadioButton = new JRadioButton("4 slices");
    panel.add(aRadioButton);
    group.add(aRadioButton);
    aRadioButton = new JRadioButton("8 slices", true);
    panel.add(aRadioButton);
    group.add(aRadioButton);
    aRadioButton = new JRadioButton("12 slices");
    panel.add(aRadioButton);
    group.add(aRadioButton);
    aRadioButton = new JRadioButton("16 slices");
    panel.add(aRadioButton);
    group.add(aRadioButton);
    Container contentPane = frame.getContentPane();
    contentPane.add(panel, BorderLayout.WEST);
    panel = new JPanel(new GridLayout(0, 1));
    border = BorderFactory.createTitledBorder("Check Boxes");
    panel.setBorder(border);
    JCheckBox aCheckBox = new JCheckBox("Anchovies");
    panel.add(aCheckBox);
    aCheckBox = new JCheckBox("Garlic", true);
    panel.add(aCheckBox);
    aCheckBox = new JCheckBox("Onions");
    panel.add(aCheckBox);
    aCheckBox = new JCheckBox("Spinach");
    panel.add(aCheckBox);
    contentPane.add(panel, BorderLayout.EAST);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}
