import javax.swing.*;
import java.util.*;

public class GetToolBarProperties {

  public static void main(String args[]) {
    JToolBar toolbar = new JToolBar();
    String classID = toolbar.getUIClassID();
    System.out.println(classID);
    String className = (String)UIManager.get(classID);
    System.out.println(className);
  }
}
