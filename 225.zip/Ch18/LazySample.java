import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.plaf.*;

public class LazySample {

  public static void main (String args[]) {

    JFrame frame = new ExitableJFrame("Lazy Example");

    Object iconObject = LookAndFeel.makeIcon(LazySample.class, "World.gif");
    UIManager.put("Tree.leafIcon", iconObject);

    Integer fifteen = new Integer(15);
    Object lazyArgs[] = new Object[] {Color.green, Boolean.TRUE, fifteen, fifteen};
    Object lazyDiamond = new UIDefaults.ProxyLazyValue("DiamondIcon", lazyArgs);
    UIManager.put("Tree.openIcon", lazyDiamond);

    JTree tree = new JTree();
    JScrollPane scrollPane = new JScrollPane(tree);

    Container contentPane = frame.getContentPane();
    contentPane.add(scrollPane, BorderLayout.CENTER);
    frame.setSize(200, 200);
    frame.setVisible(true);
  }
}
