import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.plaf.*;

public class ToolBarSample {

  private static final int COLOR_POSITION = 0;
  private static final int STRING_POSITION = 1;
  static Object buttonColors[][] = {
    {Color.red, "red"}, 
    {Color.blue, "blue"},
    {Color.green, "green"},
    {Color.black, "black"},
    null, // separator
    {Color.cyan, "cyan"}
  };

  public static void main (String args[]) {

    ActionListener actionListener = new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        System.out.println(actionEvent.getActionCommand());
      }
    };

    JFrame frame = new ExitableJFrame("JToolBar Example");

    ToolBarUI toolbarUI = new CustomToolBarUI();
    Icon imageIcon = new ImageIcon("World.gif");
    UIManager.put(CustomToolBarUI.FRAME_IMAGEICON, imageIcon);

    JToolBar toolbar = new JToolBar();
    toolbar.setUI(toolbarUI);
    toolbar.putClientProperty("JToolBar.isRollover", Boolean.TRUE);

    for (int i=0, n=buttonColors.length; i<n; i++) {
      Object color[] = buttonColors[i];
      if (color == null) {
        toolbar.addSeparator();
      } else {
        Icon icon = new DiamondIcon((Color)color[COLOR_POSITION], true, 20, 20);
        JButton button = new JButton(icon);
        button.setActionCommand((String)color[STRING_POSITION]);
        button.addActionListener(actionListener);
        toolbar.add(button);
      }
    }

    Container contentPane = frame.getContentPane();
    contentPane.add(toolbar, BorderLayout.NORTH);
    frame.setSize(350, 150);
    frame.setVisible(true);
  }
}
