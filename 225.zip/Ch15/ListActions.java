import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class ListActions {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("TextAction List");
    Container contentPane = frame.getContentPane();

    String components[] = 
      {"JTextField", "JPasswordField", "JTextArea", "JTextPane", "JEditorPane"};

    final JTextArea textArea = new JTextArea();
    textArea.setEditable(false);
    JScrollPane scrollPane = new JScrollPane(textArea);
    contentPane.add(scrollPane, BorderLayout.CENTER);

    ActionListener actionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        // Determine which component selected
        String command = actionEvent.getActionCommand();
        JTextComponent component = null;
        if (command.equals("JTextField")) {
          component = new JTextField();
        } else if (command.equals("JPasswordField")) {
          component = new JPasswordField();
        } else if (command.equals("JTextArea")) {
          component = new JTextArea();
        } else if (command.equals("JTextPane")) {
          component = new JTextPane();
        } else {
          component = new JEditorPane();
        }

        // Process action list
        Action actions[] = component.getActions();
        // Java 2 specific code to sort
        Comparator comparator = new Comparator() {
          public int compare(Object a1, Object a2) {
            int returnValue = 0;
            if ((a1 instanceof Action) && (a2 instanceof Action)) {
              String firstName = (String)((Action)a1).getValue(Action.NAME);
              String secondName = (String)((Action)a2).getValue(Action.NAME);
              returnValue = firstName.compareTo(secondName);
            }
            return returnValue;
          }
        };
        Arrays.sort(actions, comparator);
        // end Java 2 specific code
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw, true);
        int count = actions.length;
        pw.println("Count: " + count);
        for (int i=0; i<count; i++) {
          pw.print  (actions[i].getValue(Action.NAME));
          pw.print  (" : ");
          pw.println(actions[i].getClass().getName());
        }
        pw.close();
        textArea.setText(sw.toString());
        textArea.setCaretPosition(0);
      }
    };

    final Container componentsContainer = 
      RadioButtonUtils.createRadioButtonGrouping(components, "Pick to List Actions", actionListener);

    contentPane.add(componentsContainer, BorderLayout.WEST);
    frame.setSize(400, 250);
    frame.setVisible(true);
  }
}
