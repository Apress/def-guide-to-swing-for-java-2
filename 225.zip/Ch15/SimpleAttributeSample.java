import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import java.awt.*;

public class SimpleAttributeSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Simple Attributes");
    Container content = frame.getContentPane();

    StyledDocument document = new DefaultStyledDocument();

    SimpleAttributeSet attributes = new SimpleAttributeSet();
    attributes.addAttribute(StyleConstants.CharacterConstants.Bold, Boolean.TRUE);
    attributes.addAttribute(StyleConstants.CharacterConstants.Italic, Boolean.TRUE);

    // Insert content
    try {
      document.insertString(document.getLength(), "Hello Java", attributes);
    } catch (BadLocationException badLocationException) {
      System.err.println("Oops");
    }

    attributes = new SimpleAttributeSet();
    attributes.addAttribute(StyleConstants.CharacterConstants.Bold, Boolean.FALSE);
    attributes.addAttribute(StyleConstants.CharacterConstants.Italic, Boolean.FALSE);
    attributes.addAttribute(StyleConstants.CharacterConstants.Foreground, Color.lightGray);

    // Insert content
    try {
      document.insertString(document.getLength(), " - Good-bye Visual Basic", attributes);
    } catch (BadLocationException badLocationException) {
      System.err.println("Oops");
    }

   JTextPane textPane = new JTextPane(document);
    textPane.setEditable(false);
    JScrollPane scrollPane = new JScrollPane(textPane);
    content.add(scrollPane, BorderLayout.CENTER);

    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
