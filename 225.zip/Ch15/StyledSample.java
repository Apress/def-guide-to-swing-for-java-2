import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import java.awt.*;

public class StyledSample {
  public static void main(String args[]) {
    String BOLD_ITALIC = "BoldItalic";
    String GRAY_PLAIN = "Gray";
    JFrame frame = new ExitableJFrame("Simple Attributes");
    Container content = frame.getContentPane();

    StyledDocument document = new DefaultStyledDocument();

    Style style = (Style)document.getStyle(StyleContext.DEFAULT_STYLE);
    StyleConstants.setBold(style, true);
    StyleConstants.setItalic(style, true);
    document.addStyle(BOLD_ITALIC, null);

//    style = document.getStyle(StyleContext.DEFAULT_STYLE);
//    StyleConstants.setBold(style, false);
//    StyleConstants.setItalic(style, false);
//    StyleConstants.setForeground(style, Color.lightGray);
//    document.addStyle(GRAY_PLAIN, null);

    style = document.getStyle(BOLD_ITALIC);

    // Insert content
    try {
      document.insertString(document.getLength(), "Hello Java\n", style);
    } catch (BadLocationException badLocationException) {
      System.err.println("Oops");
    }

    style = document.getStyle(GRAY_PLAIN);

    // Insert content
    try {
      document.insertString(document.getLength(), " - Good-bye Visual Basic\n", style);
    } catch (BadLocationException badLocationException) {
      System.err.println("Oops");
    }

   JTextPane textPane = new JTextPane(document);
    textPane.setEditable(false);
    JScrollPane scrollPane = new JScrollPane(textPane);
    content.add(scrollPane, BorderLayout.CENTER);

    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
