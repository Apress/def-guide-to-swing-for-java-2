import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import javax.swing.text.html.parser.*;
import java.io.*;

public class LoadSync {

  public static void main (String args[]) {
    final String filename = "Test.html";
    JFrame frame = new ExitableJFrame("Loading/Saving Example");
    Container content = frame.getContentPane();

    final JEditorPane editorPane = new JEditorPane();
    editorPane.setEditable(false);
    JScrollPane scrollPane = new JScrollPane(editorPane);
    content.add(scrollPane, BorderLayout.CENTER);

    editorPane.setEditorKit(new HTMLEditorKit());

    JPanel panel = new JPanel();

    // Setup actions
    Action loadAction = new AbstractAction() {
      {
        putValue(Action.NAME, "Load");
      }
      public void actionPerformed(ActionEvent e) {
        doLoadCommand(editorPane, filename);
      }
    };
    JButton loadButton = new JButton (loadAction);
    panel.add(loadButton);

    content.add(panel, BorderLayout.SOUTH);

    frame.setSize(250, 150);
    frame.setVisible(true);
  }

  public static void doLoadCommand(JTextComponent textComponent, String filename) {
    FileReader reader = null;
    try {
      System.out.println("Loading");
      reader = new FileReader(filename);

      // Create empty HTMLDocument to read into
      HTMLEditorKit htmlKit = new HTMLEditorKit();
      HTMLDocument htmlDoc = (HTMLDocument)htmlKit.createDefaultDocument();
      // Create parser (javax.swing.text.html.parser.ParserDelegator)
      HTMLEditorKit.Parser parser = new ParserDelegator();
      // Get parser callback from document
      HTMLEditorKit.ParserCallback callback = htmlDoc.getReader(0);
      // Load it (true means to ignore character set)
      parser.parse(reader, callback, true);
      // Replace document
      textComponent.setDocument(htmlDoc);
      System.out.println("Loaded");

    } catch (IOException exception) {
      System.out.println("Load oops");
      exception.printStackTrace();
    } finally {
      if (reader != null) {
        try {
          reader.close();
        } catch (IOException ignoredException) {
        }
      }
    }
  }
}
