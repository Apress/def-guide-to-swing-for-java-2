import javax.swing.*;
import javax.swing.undo.*;
import java.awt.*;

public class UndoDrawing {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Drawing Sample");

    UndoableDrawingPanel drawingPanel = new UndoableDrawingPanel();

    UndoManager manager = new UndoManager();
    drawingPanel.addUndoableEditListener(manager);

    JToolBar toolbar = new JToolBar();
    toolbar.add(UndoManagerHelper.getUndoAction(manager));
    toolbar.add(UndoManagerHelper.getRedoAction(manager));

    Container content = frame.getContentPane();
    content.add(toolbar, BorderLayout.NORTH);
    content.add(drawingPanel, BorderLayout.CENTER);
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
