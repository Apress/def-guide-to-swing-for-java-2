import javax.swing.*;
import javax.swing.undo.*;
import java.awt.*;

public class UndoSample {
  public static void main(String args[]) {
    JFrame frame = new ExitableJFrame("Undo Sample");
    JTextArea textArea = new JTextArea();
    JScrollPane scrollPane = new JScrollPane(textArea);

    UndoManager manager = new UndoManager();
    textArea.getDocument().addUndoableEditListener(manager);

    JToolBar toolbar = new JToolBar();
    toolbar.add(UndoManagerHelper.getUndoAction(manager));
    toolbar.add(UndoManagerHelper.getRedoAction(manager));

    Container content = frame.getContentPane();
    content.add(toolbar, BorderLayout.NORTH);
    content.add(scrollPane, BorderLayout.CENTER);
    frame.setSize(300, 150);
    frame.setVisible(true);
  }
}
