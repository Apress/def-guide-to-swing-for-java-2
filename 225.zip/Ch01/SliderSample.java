import java.awt.*;
import javax.swing.*;

public class SliderSample {
  public static void main (String args[]) {
    JFrame f = new ExitableJFrame("JSlider Sample");
    Container content = f.getContentPane();
    JSlider slider = new JSlider ();
    slider.setMinorTickSpacing (5);
    slider.setMajorTickSpacing (10);
    slider.setPaintTicks (true);
    slider.setSnapToTicks(true);
    slider.setPaintTrack (false);
    slider.setPaintLabels (true);
    content.add(slider, BorderLayout.CENTER);
    f.setSize (300, 100);
    f.setVisible (true);
  }
}