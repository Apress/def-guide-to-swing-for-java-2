import java.awt.*;
import javax.swing.*;

public class TreeSample {
  public static void main (String args[]) {
    JFrame f = new ExitableJFrame("JTree Sample");
    Container content = f.getContentPane();
    JTree tree = new JTree();
    JScrollPane scrollPane = new JScrollPane(tree);
    content.add(scrollPane, BorderLayout.CENTER);
    f.setSize (300, 200);
    f.setVisible (true);
  }
}