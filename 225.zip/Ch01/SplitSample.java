import java.awt.*;
import javax.swing.*;

public class SplitSample {
  public static void main (String args[]) {
    JFrame frame = new ExitableJFrame("JSplitPane Sample");
    JSplitPane splitPane = new JSplitPane();
    splitPane.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    frame.getContentPane().add(splitPane, BorderLayout.CENTER);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}