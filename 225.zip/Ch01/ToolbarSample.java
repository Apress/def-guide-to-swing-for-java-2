import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.metal.MetalIconFactory;


public class ToolbarSample {
  public static void main (String args[]) {
    JFrame f = new ExitableJFrame("JToolbar Sample");
    Container content = f.getContentPane();
    JToolBar toolbar = new JToolBar();
    Icon icon = MetalIconFactory.getFileChooserDetailViewIcon();
    JToggleButton button = new JToggleButton(icon);
    toolbar.add(button);
    icon = MetalIconFactory.getFileChooserHomeFolderIcon();
    button = new JToggleButton(icon);
    toolbar.add(button);
    icon = MetalIconFactory.getFileChooserListViewIcon();
    button = new JToggleButton(icon);
    toolbar.add(button);
    content.add(toolbar, BorderLayout.NORTH);
    f.setSize (300, 100);
    f.setVisible (true);
  }
}