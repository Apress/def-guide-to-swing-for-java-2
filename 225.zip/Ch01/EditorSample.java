import java.awt.*;
import javax.swing.*;

public class EditorSample {
  public static void main (String args[]) {
    JFrame f = new ExitableJFrame("JEditorPane Sample");
    Container content = f.getContentPane();
    JEditorPane editor = new JEditorPane("text/html", "<H3>Help</H3><center><IMG src=file:///c:/cpress/code/Ch01/logo.jpg></center><li>One<li><i>Two</i><li><u>Three</u>");
    editor.setEditable(false);
    JScrollPane scrollPane = new JScrollPane(editor);
    content.add(scrollPane, BorderLayout.CENTER);
    f.setSize (300, 200);
    f.setVisible (true);
  }
}