import javax.swing.*;
import java.awt.*;

public class TripleListSample {
  public static void main(String args[]) {
    String labels[] = {"Chardonnay", "Sauvignon", "Riesling", "Cabernet",
      "Zinfandel", "Merlot", "Pinot Noir", "Sauvignon Blanc", "Syrah",
      "Gew�rztraminer"};
    JFrame f = new ExitableJFrame("Selection Modes");
    JList list1 = new JList(labels);
    JList list2 = new JList(labels);
    JList list3 = new JList(labels);
    Container c = f.getContentPane();
    JScrollPane sp1 = new JScrollPane(list1);
    sp1.setColumnHeaderView(new JLabel("Single Selection"));
    JScrollPane sp2 = new JScrollPane(list2);
    sp2.setColumnHeaderView(new JLabel("Single Interval"));
    JScrollPane sp3 = new JScrollPane(list3);
    sp3.setColumnHeaderView(new JLabel("Multi Interval"));
    Box box = Box.createHorizontalBox();
    box.add(sp1);
    box.add(sp2);
    box.add(sp3);
    c.add(box, BorderLayout.CENTER);
    f.setSize (300, 200);
    f.setVisible(true);
  }
}

