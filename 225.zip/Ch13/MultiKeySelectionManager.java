import javax.swing.*;
import java.awt.event.*;

public class MultiKeySelectionManager implements JComboBox.KeySelectionManager {
  private StringBuffer currentSearch = new StringBuffer();
  private Timer resetTimer;
  private final static int RESET_DELAY = 3000;
  public MultiKeySelectionManager() {
    resetTimer = new Timer(RESET_DELAY, new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        currentSearch.setLength(0);
      }
    });
  }
  public int selectionForKey(char aKey, ComboBoxModel aModel) {
    // Reset if invalid character
    if (aKey == KeyEvent.CHAR_UNDEFINED) {
      currentSearch.setLength(0);
      return -1;
    }
    // Since search, don't reset search
    resetTimer.stop();
    // Convert input to uppercase
    char key = Character.toUpperCase(aKey);
    // Build up search string
    currentSearch.append(key);
    // Find selected position within model to starting searching from
    Object selectedElement = aModel.getSelectedItem();
    int selectedIndex = -1;
    if (selectedElement != null) {
      for (int i=0, n=aModel.getSize(); i<n; i++) {
        if (aModel.getElementAt(i) == selectedElement) {
          selectedIndex = i;
          break;
        }
      }
    }
    boolean found = false;
    String search = currentSearch.toString();
    // Search from selected forward, wrap back to beginning if not found
    for (int i=0, n=aModel.getSize(); i<n; i++) {
      String element = aModel.getElementAt(selectedIndex).toString().toUpperCase();
      if (element.startsWith(search)) {
        found = true;
        break;
      }
      selectedIndex++;
      if (selectedIndex == n) {
        selectedIndex = 0; // wrap
      }
    }
    // Restart timer
    resetTimer.start();
    return (found ? selectedIndex : -1);
  }
}