import javax.swing.*;
import java.awt.*;

public class MultiKeyCombo {
  public static void main(String args[]) {
    String labels[] = {"One", "Only", "Once", "Okay",
      "oneself", "onlooker", "Onslaught", "Onyx", "onus",
      "onward"};
    JFrame f = new ExitableJFrame("Example JList");
    JComboBox jc = new JComboBox (labels);
    MultiKeySelectionManager mk = new MultiKeySelectionManager();
    jc.setKeySelectionManager (mk);
//    jc.setKeySelectionManager (new JComboBox.KeySelectionManager() {
//      public int selectionForKey (char aKey, ComboBoxModel aModel) {
//        return -1;
//      }
//    });
    Container c = f.getContentPane();
    c.add (jc, BorderLayout.NORTH);
    f.setSize (200, 200);
    f.setVisible (true);
  }
}

