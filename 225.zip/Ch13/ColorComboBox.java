import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class ColorComboBox {
  static class ColorCellRenderer implements ListCellRenderer {
    protected DefaultListCellRenderer defaultRenderer = new DefaultListCellRenderer();
     // width doesn't matter as combobox will size
    private final static Dimension preferredSize = new Dimension(0, 20);
    public Component getListCellRendererComponent(JList list, Object value, int index,
        boolean isSelected, boolean cellHasFocus) {
      JLabel renderer = (JLabel)defaultRenderer.getListCellRendererComponent(
        list, value, index, isSelected, cellHasFocus);
      if (value instanceof Color) {
        renderer.setBackground((Color)value);
      }
      renderer.setPreferredSize(preferredSize);
      return renderer;
    }
  }
  public static void main(String args[]) {
    Color colors[] = {Color.black, Color.blue, Color.cyan, Color.darkGray,
      Color.gray, Color.green, Color.lightGray, Color.magenta, Color.orange,
      Color.pink, Color.red, Color.white, Color.yellow};
    JFrame frame = new ExitableJFrame("Color JComboBox");
    Container contentPane = frame.getContentPane();

    final JComboBox comboBox = new JComboBox(colors);
    comboBox.setMaximumRowCount(5);
    comboBox.setEditable(true);
    comboBox.setRenderer(new ColorCellRenderer());
    Color color = (Color)comboBox.getSelectedItem();
    ComboBoxEditor editor = new ColorComboBoxEditor(color);
    comboBox.setEditor(editor);
    contentPane.add(comboBox, BorderLayout.NORTH);

    final JLabel label = new JLabel();
    label.setOpaque(true);
    label.setBackground((Color)comboBox.getSelectedItem());
    contentPane.add(label, BorderLayout.CENTER);

    ActionListener actionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        Color selectedColor = (Color)comboBox.getSelectedItem();
        label.setBackground(selectedColor);
      }
    };
    comboBox.addActionListener(actionListener);

    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}

