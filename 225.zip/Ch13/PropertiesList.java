import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class PropertiesList extends JList {

  SortedListModel model;
  Properties tipProps;

  public PropertiesList(Properties props) {
    model = new SortedListModel();
    setModel(model);
    ToolTipManager.sharedInstance().registerComponent(this);

    tipProps = props;
    addProperties(props);
  }
  private void addProperties(Properties props) {
    // Load
    Enumeration enum = props.propertyNames();
    while (enum.hasMoreElements()) {
      model.add(enum.nextElement());
    }
  }
  public String getToolTipText(MouseEvent event) {
    Point p = event.getPoint();
    int location = locationToIndex(p);
    String key = (String)model.getElementAt(location);
    String tip = tipProps.getProperty(key);
    return tip;
  }
  public static void main (String args[]) {
    JFrame frame = new ExitableJFrame("Custom Tip Demo");
    Properties props = System.getProperties();
    PropertiesList list = new PropertiesList(props);
    JScrollPane scrollPane = new JScrollPane(list);
    frame.getContentPane().add(scrollPane);
    frame.setSize(300, 300);
    frame.setVisible(true);
  }
}
