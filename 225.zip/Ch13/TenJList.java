import javax.swing.*;
import java.awt.*;

public class TenJList {
  public static void main(String args[]) {
    String labels[] = {"Chardonnay", "Sauvignon", "Riesling", "Cabernet",
      "Zinfandel", "Merlot", "Pinot Noir", "Sauvignon Blanc", "Syrah",
      "Gew�rztraminer"};
    JFrame f = new ExitableJFrame("Example JList");
    JList jlistNoScroll = new JList (labels);
    JList jlistScroll   = new JList (labels);
    Container c = f.getContentPane();
    c.add (jlistNoScroll, BorderLayout.WEST);
    JScrollPane sp = new JScrollPane (jlistScroll);
    c.add (sp, BorderLayout.EAST);
    f.setSize (300, 200);
    f.setVisible (true);
  }
}

