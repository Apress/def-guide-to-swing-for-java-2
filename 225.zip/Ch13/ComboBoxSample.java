import java.awt.*;
import javax.swing.*;
public class ComboBoxSample {
  public static void main(String args[]) {
    String labels[] = {"Chardonnay", "Sauvignon", "Riesling", "Cabernet",
      "Zinfandel", "Merlot", "Pinot Noir", "Sauvignon Blanc", "Syrah",
      "Gew�rztraminer"};

    String title = (args.length==0 ? "Example JComboBox" : args[0]);
    JFrame frame = new ExitableJFrame(title);
    Container contentpane = frame.getContentPane();

    JComboBox comboBox1 = new JComboBox (labels);
    comboBox1.setMaximumRowCount (5);
    contentpane.add(comboBox1, BorderLayout.NORTH);

    JComboBox comboBox2 = new JComboBox (labels);
    comboBox2.setEditable(true);
    contentpane.add(comboBox2, BorderLayout.SOUTH);

    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}

