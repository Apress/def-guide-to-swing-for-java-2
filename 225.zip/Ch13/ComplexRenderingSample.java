import javax.swing.*;
import java.awt.*;
public class ComplexRenderingSample {
  public static void main(String args[]) {
    
    Object elements[][] = {
      {new Font ("Helvetica", Font.PLAIN, 20), Color.red, 
        new DiamondIcon (Color.blue), "Help"},
      {new Font ("TimesRoman", Font.BOLD, 14), Color.blue, 
        new DiamondIcon (Color.green), "Me"},
      {new Font ("Courier", Font.ITALIC, 18), Color.green, 
        new DiamondIcon (Color.black), "I'm"},
      {new Font ("Helvetica", Font.BOLD | Font.ITALIC, 12), Color.gray, 
        new DiamondIcon (Color.magenta), "Trapped"},
      {new Font ("TimesRoman", Font.PLAIN, 32), Color.pink, 
        new DiamondIcon (Color.yellow), "Inside"},
      {new Font ("Courier", Font.BOLD, 16), Color.yellow, 
        new DiamondIcon (Color.red), "This"},
      {new Font ("Helvetica", Font.ITALIC, 8), Color.darkGray, 
        new DiamondIcon (Color.pink), "Computer"}
    };

    JFrame frame = new ExitableJFrame("Complex Renderer");
    Container contentPane = frame.getContentPane();

    JList jlist = new JList(elements);
    ListCellRenderer renderer = new ComplexCellRenderer();
    jlist.setCellRenderer(renderer);
    JScrollPane scrollPane = new JScrollPane (jlist);
    contentPane.add (scrollPane, BorderLayout.CENTER);

    JComboBox comboBox = new JComboBox(elements);
    comboBox.setRenderer(renderer);
    contentPane.add(comboBox, BorderLayout.NORTH);

    frame.setSize(300, 300);
    frame.setVisible(true);
  }
}

