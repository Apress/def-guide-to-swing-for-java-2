import javax.swing.*;
import java.awt.*;
public class DualSample {
  public static void main(String args[]) {
    String labels[] = {"Chardonnay", "Sauvignon", "Riesling", "Cabernet",
      "Zinfandel", "Merlot", "Pinot Noir", "Sauvignon Blanc", "Syrah",
      "Gew�rztraminer"};

    JFrame f = new ExitableJFrame("Sample Components");
    JList list = new JList(labels);
    JScrollPane scrollPane = new JScrollPane(list);

    JComboBox comboBox = new JComboBox(labels);
    comboBox.setMaximumRowCount(4);

    Container contentPane = f.getContentPane();
    contentPane.add(comboBox, BorderLayout.NORTH);
    contentPane.add(scrollPane, BorderLayout.CENTER);

    f.setSize (300, 200);
    f.setVisible (true);
  }
}
