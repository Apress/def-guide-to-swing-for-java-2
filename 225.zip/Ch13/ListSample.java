import javax.swing.*;
import java.awt.*;
public class ListSample {
  public static void main(String args[]) {
    String labels[] = {"Chardonnay", "Sauvignon", "Riesling", "Cabernet",
      "Zinfandel", "Merlot", "Pinot Noir", "Sauvignon Blanc", "Syrah",
      "Gew�rztraminer"};

    String title = (args.length==0 ? "JList Sample" : args[0]);
    JFrame f = new ExitableJFrame(title);
    JList list = new JList(labels);
    JScrollPane scrollPane = new JScrollPane(list);

    Container contentPane = f.getContentPane();
    contentPane.add(scrollPane, BorderLayout.CENTER);

    f.setSize(200, 200);
    f.setVisible(true);
  }
}
