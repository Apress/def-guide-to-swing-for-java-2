import javax.swing.*;
import java.awt.*;
public class CustomBorderSample {
  public static void main(String args[]) {
    String labels[] = {"Chardonnay", "Sauvignon", "Riesling", "Cabernet",
      "Zinfandel", "Merlot", "Pinot Noir", "Sauvignon Blanc", "Syrah",
      "Gew�rztraminer"};
    JFrame frame = new ExitableJFrame("Custom Border");
    Container contentPane = frame.getContentPane();
    JList jlist = new JList(labels);
    ListCellRenderer renderer = new FocusedTitleListCellRenderer();
    jlist.setCellRenderer(renderer);
    JScrollPane sp = new JScrollPane(jlist);
    contentPane.add(sp, BorderLayout.CENTER);
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}

