import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class EditComboBox {
  public static void main(String args[]) {
    String labels[] = {"Chardonnay", "Sauvignon", "Riesling", "Cabernet",
      "Zinfandel", "Merlot", "Pinot Noir", "Sauvignon Blanc", "Syrah",
      "Gew�rztraminer"};
    JFrame frame = new ExitableJFrame("Editable JComboBox");
    Container contentPane = frame.getContentPane();

    final JComboBox comboBox = new JComboBox(labels);
    comboBox.setMaximumRowCount(5);
    comboBox.setEditable(true);
    contentPane.add (comboBox, BorderLayout.NORTH);

    final JTextArea textArea = new JTextArea();
    JScrollPane scrollPane = new JScrollPane(textArea);
    contentPane.add(scrollPane, BorderLayout.CENTER);

    ActionListener actionListener = new ActionListener() {
      public void actionPerformed (ActionEvent actionEvent) {
        textArea.append("Selected: " + comboBox.getSelectedItem());
        textArea.append(", Position: " + comboBox.getSelectedIndex());
        textArea.append(System.getProperty("line.separator"));
      }
    };
    comboBox.addActionListener(actionListener);

    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}

